<? include_once("config.php");
$site_title="Contact";
?> 
<!DOCTYPE HTML>
<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Contact | Free Home Delivery Fruits &amp; Vegetables Gurgaon</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="description" content=" Contact for Sabji On Wheels delivers fresh and best quality fruits &amp; vegetables at your doorstep in Gurgaon.">
<meta name="keywords" content="home delivery vegetables, free delivery fruits in gurgaon, sabji market gurgaon">

<? include_once("commonTemplate/head.php")?> 


<script>(function() {
  var _fbq = window._fbq || (window._fbq = []);
  if (!_fbq.loaded) {
    var fbds = document.createElement('script');
    fbds.async = true;
    fbds.src = '//connect.facebook.net/en_US/fbds.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(fbds, s);
    _fbq.loaded = true;
  }
  _fbq.push(['addPixelId', '1400018226953897']);
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', 'PixelInitialized', {}]);
</script>
<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=1400018226953897&amp;ev=NoScript" /></noscript>

</head>

<body>
<? include_once("commonTemplate/header.php")?> 
<section>
 <div class="feedback-outer">
  <div class="feedback-inner">
<div class="feedback-left">
<div class="feeback-heading">

<span style="font-size:20px;color:orange;font-family:Cooper Black;">Call Us for placing your orders:</span><BR> 

</div>
<div class="contact-content">
<span style="font-size:20px;color:orange;font-family:Cooper Black;">Our telephone number is


<strong>+91 9310056669</strong><br>
<br>


<b><u>Our lines are open:</b></u><br>

Mon to sat: 9.00 am - 9.00 pm <br>

Sun: 9.00am - 12.00pm <br><br>

Our email address is <em><strong>orders@sabjionwheels.com</strong></em><strong></strong><br><br>
For any Complains &amp; feedbacks please drop an email at  
feedbacks@sabjionwheels<br>
<br>
</span>

<span style="font-size:20px;font-family:Cooper Black; color:#c0504d;">For Business and Marketing related Enquiries contact below mentioned numbers.<br><br>


+918860001153(INDIA)<br>
+442036086273 (UK)<br>
+17605144306 (USA)<br>
<br>
<br>
<br><iframe src='http://www.flipkart.com/affiliate/displayWidget?affrid=WRID-142178506309337368' frameborder=0 height=90 width=728></iframe>
</span>


</div>

</div>
<div class="feedback-right2 hidden-img"><img width="280" height="276" alt="contact" src="img/contact.jpg"></div>
 </div>
 </div>
</section>
<div style="clear:both;"></div>
<? include_once("commonTemplate/footer.php")?> 
</body>
</html>