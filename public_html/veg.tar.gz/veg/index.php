<? include_once("config.php");
   
?>

<!DOCTYPE HTML>

<html><head>
<meta name="google-site-verification" content="PQqGFdBFGqyBG7Y96lkEZXzMpy-cW8z1NMPG6zDhzyE" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Free Home Delivery Fruits &amp; Vegetables Gurgaon</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">

<meta name="keywords" content="home delivery vegetables, free delivery fruits in gurgaon, sabji market gurgaon">

<meta name="description" content="Sabji On Wheels delivers fresh and best quality fruits &amp;Online vegetables at your doorstep directly with the best farmers in Gurgaon.">

<? include_once("commonTemplate/head.php")?> 

<script type='text/javascript' src="js/jquery-1.7.1.min.js"></script>

<script src="js/bjqs-1.3.min.js"></script>



<!-- Facebook Conversion Code for Leads -->

<script>(function() {

var _fbq = window._fbq || (window._fbq = []);

if (!_fbq.loaded) {

var fbds = document.createElement('script');

fbds.async = true;

fbds.src = '//connect.facebook.net/en_US/fbds.js';

var s = document.getElementsByTagName('script')[0];

s.parentNode.insertBefore(fbds, s);

_fbq.loaded = true;

}

})();

window._fbq = window._fbq || [];

window._fbq.push(['track', '6015085393536', {'value':'0.00','currency':'INR'}]);

</script>

<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?ev=6015085393536&amp;cd[value]=0.00&amp;cd[currency]=INR&amp;noscript=1" /></noscript>



    

        <script type="text/javascript">

        $(document).ready(function() {



            var id = '#dialog';



            //Get the screen height and width

            var maskHeight = $(document).height();

            var maskWidth = $(window).width();



            //Set heigth and width to mask to fill up the whole screen

            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });



            //transition effect

            $('#mask').fadeIn(1000);

            $('#mask').fadeTo("slow", 0.8);



            //Get the window height and width

            var winH = $(window).height();

            var winW = $(window).width();



            //Set the popup window to center

            $(id).css('top', winH / 2 - $(id).height() / 2);

            $(id).css('left', winW / 2 - $(id).width() / 2);



            //transition effect

            $(id).fadeIn(2000);



            //if close button is clicked

            $('.window .close').click(function(e) {

                //Cancel the link behavior

                e.preventDefault();



                $('#mask').hide();

                $('.window').hide();

            });



            //if mask is clicked

            $('#mask').click(function() {

                $(this).hide();

                $('.window').hide();

            });

			

        

				 setTimeout( "jQuery('#mask').hide();",15000 );

				  setTimeout( "jQuery('.window').hide();",15000 );

				  setTimeout(function(){$('#mask').fadeOut();}, 2000);

				  setTimeout(function(){$('.window').fadeOut();}, 2000);

	  



        });



    </script>

<script src="js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script>

<script type="text/javascript">

$(document).ready(function(){

$('#layerslider').layerSlider({

skinsPath : 'layerslider/skins/',

skin : 'fullwidth',

thumbnailNavigation : 'hover',

hoverPrevNext : true,

responsive : true,

responsiveUnder :940,

thumbnailNavigation : false,

sublayerContainer : 1000

});

});		

</script>

<script src="js/jquery.themepunch.plugins.min.js"></script>    

</head>

<body>

<? include_once("commonTemplate/header.php")?>

<section>

  <div class="banner-area">

    <div class="banner-left">

      <div class="left" style="height:246px; margin-bottom:10px;">

        <h3 style="text-align:center;font-family:Jokerman; padding-bottom:8px;font-size:24px">HEALTHY EATING</h3>
<span style="font-size:16px;font-family:Kristen ITC; color:orange;">

        <b><i>Only eat chemical free Veggies. Who wants harsh chemicals along with their breakfast? We certainly don’t, & guess you’re with us!  

“The food you eat can be either the safest and most powerful form of medicine or the slowest form of poison.” 

</i></b></span>
<br>

        <a href="offer.php"><img src="img/special.jpg" width="68" height="108" style=" padding-right:10px;"></a><img src="img/guarantee.jpg" width="99" height="103" style=" width:60%">

        <div align="right"></div>

      </div>

    </div>

    <div class="right">

     <div id="banner-slide">

 <div id="layerslider-container-fw">

  <div id="layerslider">
<div class="ls-layer" style="slidedirection:right; slidedelay: 6000; durationin: 500; background:#000; durationout: 1500; delayout: 500;">
 <img src="img/vegetable-box.jpg" class="ls-s3" alt="Vegetable Delivery Gurgaon" style="top:0px; left:50%;  slidedirection :right; slideoutdirection : left; durationin :1000; durationout : 750; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
<img src="img/fruit-Boxes1.jpg" id="img" class="ls-s3" alt="Free Home Delivery Fruit Gurgaon" style="top:99px; left:50%;  slidedirection :left; slideoutdirection :right; durationin : 2000; durationout :1450; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
<img src="img/mixed-fruit.jpg" alt="Mixed Fruit Delivery" id="img2" width="706" height="97" class="ls-s3" style="top:201px; left:50%;  slidedirection :right; slideoutdirection :right; durationin :3000; durationout :2050; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
</div>
<div class="ls-layer" style="slidedirection:right; slidedelay: 6000; durationin: 500; background:#70912c; durationout: 1500; delayout: 500;">
<img src="img/exotic-fruit.jpg" class="ls-s3"  alt="exotic fruit buy online" style="top:0px; left:50%;  slidedirection :right; slideoutdirection : left; durationin :1000; durationout : 750; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
<img src="img/citrus-fruits1.jpg" class="ls-s3" id="img" alt="citrus online shopping gurgaon" style="top:99px; left:50%;  slidedirection :left; slideoutdirection :right; durationin : 2000; durationout :1450; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">

<img src="img/apples1.jpg" class="ls-s3" id="img2" alt="buy online apple" style="top:200px; left:50%;  slidedirection :right; slideoutdirection :right; durationin :3000; durationout :2050; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
</div>

<div class="ls-layer" style="slidedirection:right; slidedelay: 6000; durationin: 500; background:#c0504d; durationout: 1500; delayout: 500;">

<img src="img/vegetables1.jpg" class="ls-s3" alt="buy garlic ginger vegetables" style="top:0px; left:50%;  slidedirection :right; slideoutdirection : left; durationin :1000; durationout : 750; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
<img src="img/vegetables2.jpg" class="ls-s3" id="img" alt="squash vegetables" style="top:99px; left:50%;  slidedirection :left; slideoutdirection :right; durationin : 2000; durationout :1450; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
<img src="img/vegetables3.jpg" class="ls-s3" id="img2" alt="peppers aubergine" style="top:201px; left:50%;  slidedirection :right; slideoutdirection :right; durationin :3000; durationout :2050; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">

      </div>

  <!-- Slider / End -->
</div></div></div></div></div>
<div class="middle-area">
<div class="middle-second">
<div class="middle-box3">
<div class="heading">
<span style="color:#c0504d;font-family:Jokerman; font-size:18px;">HEALTH BOXES</span></div>
<br><br>
<span style="color:#4f6228;font-size:20px;font-family:kristen itc; "><b>Welcome To Health!!</b></span>

<div class="content"> 
<span style="color:#c0504d;font-family:Berlin Sans FB Demi; font-size:14px;"><b><i>Health Issues due to Hectic Lifestyle?? </span><br>
<span style="color:green;font-family:Berlin Sans FB Demi; font-size:14px;">Don't worry we have a solutions for you!! </span><br>

<span style="color:orange;font-family:Berlin Sans FB Demi; font-size:14px;">Check out our complete range of HEALTH BOXES with Magic Health Benefits in the Colors of Fruits and Vegetables.</span>

<div align="right"><a href="health.php" class="click-butt">Click Here</a></div>
</div></div>
<div class="middle-box">
<div class="heading">
<span style="color:#c0504d;font-family:Jokerman; font-size:18px;">VEGETABLES</span></div>

        <img src="img/box-product.jpg" width="188" height="158" alt="vegetable box">

        <div class="content"> <span style="color:#00b08f;font-family:Berlin Sans FB Demi; font-size:15px;"><b><i>Check Our complete range of Fresh & Healthy Hand Picked Vegetables.</i></b>
</span>

<div align="right"><a href="vegetables.php" class="click-butt">Click Here</a></div></div></div>

<div class="middle-box">
<div class="heading">

<span style="color:#c0504d;font-family:Jokerman; font-size:18px;">FRUITS</span></div>
<img src="img/box-product1.jpg" width="188" height="158" alt="vegetable box"> 
<div class="content"> <span style="color:orange;font-family:Berlin Sans FB Demi; font-size:15px;"><br><b><i>Feel Our best Quality Fruits that will make you Happy.</i></b></span>
<div align="right"><a href="fruits.php" class="click-butt">Click Here</a></div></div></div>
<div class="middle-box" style="margin-right:0px;">

<div class="heading">
<span style="color:#c0504d;font-family:Jokerman; font-size:18px;">WEEKLY BOXES</span></div>

<img src="img/box-product2.jpg" width="188" height="158" alt="vegetable box">

<div class="content"><span style="color:green;font-family:Berlin Sans FB Demi; font-size:15px;"><b><i>Weekly boxes as per your needs!! It's a good way to save some more money & time.</i></b></span>
<div align="right"><a href="weekly.php" class="click-butt">Click Here</a></div></div></div>
<div class="middle-box3" style="color:#C0504D">

<div class="heading">
<span style="font-family:Jokerman; font-size:20px; color: #c0504d;">Competitive Prices</span></div>
<br><br><div class="content"> 

<span style="color:green;font-family:Berlin Sans FB Demi; font-size:15px;"><b><i>Sabji On Wheels delivers fresh and best quality fruits & vegetables at your doorstep. We work directly with the best farmers in the land. They're the best in their field. We know exactly how your food is made, how it's grown and what does, or more importantly doesn't, go into it.</i></b> </span>
</div>
</div>
 <div class="middle-box3"  style="color:#C0504D">

        <div class="heading">

<span style="font-family:Jokerman; color: #c0504d; font-size:16px; line-height:6px; ">Weekly Combo Offers!</span></div>
<img src="img/specialoffers.jpg" width="188" height="158"  alt="vegetable box">
       <div class="content" style="line-height:17px;">
<span style="color:orange;font-family:Berlin Sans FB Demi; font-size:15px;"><b><i><span style="color:#000"> Amazing Weekly Offers on Mandi Rates.Check Now and enjoy the freedom of healthy shopping.</span><br>
</i></b>
</span><div align="right"><a href="combooffers.php" class="click-butt">Click Here</a></div></div></div></div>

<div class="middle-box2">
<a href="http://www.freepepper.com">
        <img src="img/FreeGift11.png" alt="add">

      </div>
      <div class="middle-box3" style="margin-right:0px; height:330px">

      <a href="http://www.freepepper.com">
<div class="heading">

<span style="font-family:Jokerman; font-size:20px; color: #c0504d;"></span></div>
<marquee behavior="scroll" direction="up" scrolldelay="5" scrollamount="3" onMouseOver="this.stop()" onMouseOut="this.start()" style="padding-left: 5px; height: 270px; color:green;">
<b><i> 
</i></b></marquee>
        
 </a>
</div>
</div>
</div>
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>