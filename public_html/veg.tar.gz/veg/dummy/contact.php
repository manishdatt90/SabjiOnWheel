<? include_once("config.php");
$site_title="Contact";
?> 
<!DOCTYPE HTML>
<html>
<head>
<? include_once("commonTemplate/head.php")?> 
</head>

<body>
<? include_once("commonTemplate/header.php")?> 
<section>
 <div class="feedback-outer">
  <div class="feedback-inner">
<div class="feedback-left">
<div class="feeback-heading">

<span style="font-size:20px;color:orange;font-family:Cooper Black;">Call Us for placing your orders:</span><BR> 

</div>
<div class="contact-content">
<span style="font-size:20px;color:orange;font-family:Cooper Black;">Our telephone number is


<strong>+91 9310056669</strong><br>
<br>


<b><u>Our lines are open:</b></u><br>

Mon to sat: 9.00 am - 9.00 pm <br>

Sun: 9.00am - 12.00pm <br><br>

Our email address is <em><strong>orders@sabjionwheels.com</strong></em><strong></strong><br><br>
For any Complains &amp; feedbacks please drop an email at  
feedbacks@sabjionwheels<br>
<br>
</span>

<span style="font-size:20px;font-family:Cooper Black; color:#c0504d;">For Business and Marketing related Enquiries contact below mentioned numbers.<br><br>


+918860001153(INDIA)<br>
+442036086273 (UK)<br>
+17605144306 (USA)<br>
</span>


</div>

</div>
<div class="feedback-right2 hidden-img"><img width="280" height="276" alt="contact" src="img/contact.jpg"></div>
 </div>
 </div>
</section>
<div style="clear:both;"></div>
<? include_once("commonTemplate/footer.php")?> 
</body>
</html>