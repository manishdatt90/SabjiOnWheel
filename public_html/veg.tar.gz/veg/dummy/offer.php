<? include_once("config.php");
$site_title="Offer";
?>
<!DOCTYPE HTML>
<html>
<head>
<? include_once("commonTemplate/head.php")?>
</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
<div class="divbox-left">
<div class="feeback-heading" style="color:#C0504D">Monthly Discounts:</div>
<div class="how-order" style="color:#548dd4;">
<ul type="circle">
<li style="color:#948a54;">If your order reach Rs.1000 or more, you will get 5% Off on the total bill.(Not included Boxes)</li>
<li style="color:#c0504d;">For advance orders you will get 5% Off on the total bill. (For example: If you need delivery on 10th May and you placed your order on 9th May then you will get 5% off on the total bill.)</li>
<li style="color:#9bbb59;"></li>

</ul>
</div>
<div class="how-order">

<div class="feeback-heading" style="color:#C0504D">Referral Discounts:</div>

Refer our services to your friends. You will get 10% off on your next order with us. 
Just follow the steps and have 10% off on your next order with us:


<br>
<br>

</div>
<div class="how-order" style="color:#1f497d;">Process:

<ul type="circle">
<li style="color:#1f497d;">Step 1: Just refer our services to your friends.</li>
<li style="color:#c03535;">Step 2:  Ask your friends to mention your name &amp; Mobile number to us while placing orders.</li>
<li style="color:#225990;">Step 3: SABJI ON WHEELS will make a note of your referral and feed in the system.</li>
<li style="color:#00b050;">Step 4:You will get 10% discount on your next order with us. Just mention your friend's name to whom you referred our services.</li>
<li style="color:#1f497d;">STEP 5: Our Customer care executive will check in the system and will provide you your discounts.</li>
</ul>


</div>


</div>
<div class="divbox-right"><img src="img/offer1.jpg" width="275" height="204" alt="offer" style="float:right"></div>
<div class="divbox-right"><img src="img/offer2.jpg" width="275" height="204" alt="offer" style="float:right"></div>
<div class="divbox-right"><img src="img/offer3.jpg" width="275" height="204" alt="offer" style="float:right"></div>

 </div>
 </div>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>
