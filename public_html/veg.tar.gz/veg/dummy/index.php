<? include_once("config.php")?>
<!DOCTYPE HTML>
<html>
<head>
<? include_once("commonTemplate/head.php")?> 

</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
  <div class="banner-area">
    <div class="banner-left">
      <div class="left" style="height:246px; margin-bottom:10px;">
        <h3 style="text-align:center;font-family:Jokerman; padding-bottom:8px;font-size:28px">Hello & Welcome</h3>


<span style="font-size:16px;font-family:Kristen ITC; color:orange;">
        <b><i>Love good food? We've got weekly boxes of it for you. Seasonal and organic fruit, 
        veg and more to your door. 
        You just need to let us know day & time to deliver your weekly boxes.
        To see what we have in our bags of boxes for you.</i></b></span>

        <br>
        <a href="offer.html"><img src="img/special.jpg" width="68" height="108" style=" padding-right:10px;"></a><img src="img/guarantee.jpg" width="99" height="103" style=" width:60%">
        <div align="right"></div>
      </div>
    </div>
    <div class="right">
     <div id="banner-slide">
 <div id="layerslider-container-fw">
  <div id="layerslider">
  
    <div class="ls-layer" style="slidedirection:right; slidedelay: 6000; durationin: 500; background:#000; durationout: 1500; delayout: 500;">
     <img src="img/vegetable-box.jpg" class="ls-s3" alt="" style="top:0px; left:50%;  slidedirection :right; slideoutdirection : left; durationin :1000; durationout : 750; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
 
           <img src="img/fruit-Boxes1.jpg" id="img" class="ls-s3" alt="" style="top:99px; left:50%;  slidedirection :left; slideoutdirection :right; durationin : 2000; durationout :1450; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
           
                <img src="img/mixed-fruit.jpg" alt="" id="img2" width="706" height="97" class="ls-s3" style="top:201px; left:50%;  slidedirection :right; slideoutdirection :right; durationin :3000; durationout :2050; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
      </div>
    
      <div class="ls-layer" style="slidedirection:right; slidedelay: 6000; durationin: 500; background:#70912c; durationout: 1500; delayout: 500;">
     <img src="img/exotic-fruit.jpg" class="ls-s3"  alt="" style="top:0px; left:50%;  slidedirection :right; slideoutdirection : left; durationin :1000; durationout : 750; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
 
           <img src="img/citrus-fruits1.jpg" class="ls-s3" id="img" alt="" style="top:99px; left:50%;  slidedirection :left; slideoutdirection :right; durationin : 2000; durationout :1450; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
           
                <img src="img/apples1.jpg" class="ls-s3" id="img2" alt="" style="top:200px; left:50%;  slidedirection :right; slideoutdirection :right; durationin :3000; durationout :2050; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
      </div>
      
        <div class="ls-layer" style="slidedirection:right; slidedelay: 6000; durationin: 500; background:#c0504d; durationout: 1500; delayout: 500;">
     <img src="img/vegetables1.jpg" class="ls-s3" alt="" style="top:0px; left:50%;  slidedirection :right; slideoutdirection : left; durationin :1000; durationout : 750; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
 
           <img src="img/vegetables2.jpg" class="ls-s3" id="img" alt="" style="top:99px; left:50%;  slidedirection :left; slideoutdirection :right; durationin : 2000; durationout :1450; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
           
                <img src="img/vegetables3.jpg" class="ls-s3" id="img2" alt="" style="top:201px; left:50%;  slidedirection :right; slideoutdirection :right; durationin :3000; durationout :2050; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 1500;">
      </div>
 

  <!-- Slider / End -->

      </div>
    </div>
  </div>
    </div>
  </div>
    
  <div class="middle-area">
    <div class="middle-second">
      <div class="middle-box3">
        <div class="heading">
	<span style="color:#c0504d;font-family:Jokerman; font-size:18px;">HEALTH BOXES</span></div>
        <br>
        <br>
        <span style="color:#4f6228;font-size:20px;font-family:kristen itc; "><b>Welcome To
          Health!!</b></span>
        <div class="content"> 
<span style="color:#c0504d;font-family:Berlin Sans FB Demi; font-size:14px;"><b><i>Health Issues due to Hectic Lifestyle?? </span><br>
          <span style="color:green;font-family:Berlin Sans FB Demi; font-size:14px;">Don't worry we have a solutions for you!! </span><br>
          <span style="color:orange;font-family:Berlin Sans FB Demi; font-size:14px;">Check out our complete range of HEALTH BOXES with Magic Health Benefits in the Colors of Fruits and Vegetables.</span>
          <div align="right"><a href="health.html" class="click-butt">Click Here</a></div>
        </div>
      </div>
      <div class="middle-box">
        <div class="heading">
<span style="color:#c0504d;font-family:Jokerman; font-size:18px;">VEGETABLES</span></div>
        <img src="img/box-product.jpg" width="188" height="158" alt="vegetable">
        <div class="content"> <span style="color:#00b08f;font-family:Berlin Sans FB Demi; font-size:15px;"><b><i>Check Our complete range of Fresh & Healthy Hand Picked Vegetables.</i></b>
        </span>
          <div align="right"><a href="vegetables.html" class="click-butt">Click Here</a></div>
        </div>
      </div>
      <div class="middle-box">
        <div class="heading">
<span style="color:#c0504d;font-family:Jokerman; font-size:18px;">FRUITS</span></div>

<img src="img/box-product1.jpg" width="188" height="158" alt="vegetable"> 
        <div class="content"> <span style="color:orange;font-family:Berlin Sans FB Demi; font-size:15px;"><br><b><i>Feel Our best Quality Fruits that will make you Happy.</i></b></span>
          <div align="right"><a href="fruits.html" class="click-butt">Click Here</a></div>
        </div>
    </div>
      <div class="middle-box" style="margin-right:0px;">
        <div class="heading">
<span style="color:#c0504d;font-family:Jokerman; font-size:18px;">WEEKLY BOXES</span></div>
        <img src="img/box-product2.jpg" width="188" height="158" alt="vegetable">
        <div class="content"><span style="color:green;font-family:Berlin Sans FB Demi; font-size:15px;"><b><i>Weekly boxes as per your needs!! It's a good way to save some more money & time.</i></b></span>
          <div align="right"><a href="weekly.html" class="click-butt">Click Here</a></div>
        </div>
      </div>

  

      <div class="middle-box3" style="color:#C0504D">
        <div class="heading">
	<span style="font-family:Jokerman; font-size:20px; color: #c0504d;">Competitive Prices</span></div>
        <br>
        <br>
        <div class="content"> 
<span style="color:green;font-family:Berlin Sans FB Demi; font-size:15px;"><b><i>Sabji On Wheels delivers fresh and best quality fruits & vegetables at your doorstep. We work directly with the best farmers in the land. They're the best in their field. We know exactly how your food is made, how it's grown and what does, or more importantly doesn't, go into it.</i></b> </span>
</div>
      </div>
      
      
      <div class="middle-box3"  style="color:#C0504D">
        <div class="heading">
<span style="font-family:Jokerman; color: #c0504d; font-size:16px; line-height:6px; ">Share & Get discounts Everyday!!</span></div>
       <div class="content" style="line-height:17px;">
<span style="color:orange;font-family:Berlin Sans FB Demi; font-size:15px;"><b><i><span style="color:#000">You Liked Our Services? If, Yes.
Why don't you refer our services to your friends circle? What's your benefit?</span> You will get another 10%Discount on your next order.
You liked it? We have something for your friends & family as well. Your friend will also get 10% <span style="color:#900">Discount on his/her first order.</span> You liked it?
We have more offers in our bags every time you place your orders with us.
</i></b>
</span>
    
        </div>
      </div>
      
      
    </div>
    <div class="middle-box2">
      
        <img src="img/add.jpg" alt="add">
    
      </div>
      
      
      <div class="middle-box3" style="margin-right:0px; height:330px">
      <a href="recipe.html">
        <div class="heading">
<span style="font-family:Jokerman; font-size:20px; color: #c0504d;">Offer of the Month</span></div>
       
          <marquee behavior="scroll" direction="up" scrolldelay="5" scrollamount="3" onMouseOver="this.stop()" onMouseOut="this.start()" style="padding-left: 5px; height: 270px; color:green;">
         <b><i>
Mango Safeda - HIGH GRADE @ Rs. 50 per KG.<br><br>
Mango Safeda - HIGH GRADE @ Rs. 50 per KG.<br><br>
Mango Safeda - HIGH GRADE @ Rs. 50 per KG.<br><br>
Mango Safeda - HIGH GRADE @ Rs. 50 per KG.<br><br>
          </i></b>
          </marquee>
      
        </a>
      </div>
      

      </div>
  </div>
  
  
  
  
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>