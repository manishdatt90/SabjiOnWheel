<? include_once("config.php");
$site_title="Thanks";
?> 
<!DOCTYPE HTML>
<html>
<head>
<? include_once("commonTemplate/head.php")?> 

</head>

<body>
<? include_once("commonTemplate/header.php")?> 
<div class="feedback-outer">
  <div class="feedback-inner">
  <div class="feeback-heading">Thanks</div>
  <br><img src="img/thanks.png" align="middle" class="img-size" />
  </div>
 </div>
</section>
<? include_once("commonTemplate/footer.php")?>

</body>
</html>
