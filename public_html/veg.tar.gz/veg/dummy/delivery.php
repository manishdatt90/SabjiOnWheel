<? include_once("config.php");
$site_title="Delivery";
?> 
<!DOCTYPE HTML>
<html>
<head>
<? include_once("commonTemplate/head.php")?> 
</head>

<body>
<? include_once("commonTemplate/header.php")?> 
<section>
  <div class="feedback-outer">
  <div class="feedback-inner">
<div class="feedback-left">
<div class="feeback-heading">
<div class="delivery-left"><strong>4 Delivery slots</strong></div>
</div>
<br>
<br>

<div class="delivery-middle">
<p><span class="span-1">SLOT 1.</span>		<span class="span-2">9:00 AM &ndash; 12:00 NOON</span>	<span class="span-3">Monday to Saturday</span></p>
<p><span class="span-1">SLOT 2.</span>		<span class="span-2">12:00 PM &ndash; 03:00 PM</span>	<span class="span-3">Monday to Saturday</span></p>
<p><span class="span-1">SLOT 3.</span>		<span class="span-2">03:00 PM &ndash; 06:00 PM</span>	<span class="span-3">Monday to Saturday</span></p>
<p><span class="span-1">SLOT 4.</span>		<span class="span-2">06:00 PM &ndash; 09:00 PM</span>	<span class="span-3">Monday to Saturday</span></p>

</div>

<div class="feeback-heading">
<div style="color:#76923c; margin-top:10px;" class="delivery-left"><strong>For Placing Orders<br>

 <span style="font-size:16px;">Call Us @ 9310056669 <br>
Or Email Us: orders@sabjionwheels.com</span>
</strong></div>

</div>


<div style="color:#943634; margin-top:10px;" class="delivery-middle">
<span class="span-1">Timings</span><span class="span-2">
09:00 AM &ndash; 09:00 PM
</span>	<span class="span-3">Monday to Saturday</span>


</div>

</div>
<div class="delivery-right"><img width="300" height="209" alt="delivery" src="img/delivery.jpg"></div>


 </div>
 </div>
  
  
</section>
<div style="clear:both;"></div>
<? include_once("commonTemplate/footer.php")?> 
</body>
</html>
