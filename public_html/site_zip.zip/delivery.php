<? include_once("config.php");
$site_title="Delivery";
?> 
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Delivery | Home Delivery Fruits &amp; Vegetables Gurgaon</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="description" content="Delivery for Sabji On Wheels delivers fresh and best quality fruits &amp; vegetables at your doorstep in Gurgaon.">
<meta name="keywords" content="home delivery vegetables, free delivery fruits in gurgaon, sabji market gurgaon">
<? include_once("commonTemplate/head.php")?> 


<script>(function() {
  var _fbq = window._fbq || (window._fbq = []);
  if (!_fbq.loaded) {
    var fbds = document.createElement('script');
    fbds.async = true;
    fbds.src = '//connect.facebook.net/en_US/fbds.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(fbds, s);
    _fbq.loaded = true;
  }
  _fbq.push(['addPixelId', '1400018226953897']);
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', 'PixelInitialized', {}]);
</script>
<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=1400018226953897&amp;ev=NoScript" /></noscript>

</head>

<body>
<? include_once("commonTemplate/header.php")?> 
<section>
  <div class="feedback-outer">
  <div class="feedback-inner">
<div class="feedback-left">
<div class="feeback-heading">
<div class="delivery-left"><strong> 3 Delivery slots</strong></div>
</div>
<br>

<div class="delivery-middle">
<p><span class="span-1">SLOT 1.</span>		<span class="span-2">09:30 AM &ndash; 01:00 PM</span>	<span class="span-3">Monday to Saturday</span></p>
<p><span class="span-1">SLOT 2.</span>		<span class="span-2">11:00 AM &ndash; 3:00 PM</span>	<span class="span-3">Monday to Saturday</span></p>
<p><span class="span-1">SLOT 3.</span>		<span class="span-2">04:00 PM &ndash; 07:00 PM</span>	<span class="span-3">Monday to Saturday</span></p>
<p><span class="span-1">SLOT 4.</span>		<span class="span-2">06:00 PM &ndash; 09:00 PM</span>	<span class="span-3">Monday to Saturday</span></p><br>


</div>
<div class="feeback-heading">
<div style="color:#76923c; margin-top:10px;" class="delivery-left"><br>
<br>
For Placing Orders<br><br>

 <span style="font-size:19px;">Call Us @ 9310056669 <br>
Or Email Us: orders@sabjionwheels.com <br>
Or Online: WWW.SABJIONWHEELS.COM</span>
</div>

</div>


<div style="color:#943634; margin-top:10px;" class="delivery-middle">
<span class="span-1">Timings</span><span class="span-2">
09:00 AM &ndash; 09:00 PM
</span>	<span class="span-3">Monday to Saturday</span>
<br>



</div>

</div>
<div class="delivery-right"><img width="300" height="209" alt="" src="img/"></div>
<iframe src='http://www.flipkart.com/affiliate/displayWidget?affrid=WRID-142178506309337368' frameborder=0 height=90 width=728></iframe>

 </div>
 </div>

  
  
</section>
<div style="clear:both;"></div>
<? include_once("commonTemplate/footer.php")?> 
</body>
</html>
