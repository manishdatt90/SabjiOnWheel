<? include_once("config.php");
$site_title="Offer";
?>
<!DOCTYPE HTML>
<html>
<head>
<? include_once("commonTemplate/head.php")?>
</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
<div class="divbox-center">
<div class="feeback-heading" style="color:#C0504D"> About Sabji On Wheels!!


</div>
<div class="how-order">
Sabji on wheels, one of the fastest growing startups in gurgaon and  consumer space has sparked a new market opportunity  providing home delivery of fruits and vegetables throughout the gurgaon. It was started  in April’14 with the motto of delivering fresh sabjis at gurgaon-ies doorstep. </br></br>
The team behind Sabji On Wheels are two brothers Arun Gupta & Gaurav Gupta, Software Enginner & Civil Engineer by qualifications and have good experience of Corporate Sector. Brothers are basically from Hissar, Haryana. Coming from business family,these two wanted to start something on their own. Given their technology background and need to meet daily requirements of sabji consumers in gurgaon,they started ‘Sabji On Wheels’ firm.</br></br>
The vision behind start up is to provide consumers hassle-free, reliable and convenient delivery of sabjis at their doorstep with most competitive market price. This firm operates through www.sabjionwheels.com website where users can login and place orders. A new concept introduced by sabji on wheels is ‘Health Boxes’ and ‘Weekly Boxes’ that has been big hit among customers, a healthy variety of flavours and nutrients. A health box consist of mixed fruits and vegetables that are beneficial for healing any disease like diabetes, arthritis, osteoporosis or to control different body mechanics like skin care, pregnancy, liver detoxification, BP. On the other hand weekly box is a box that can suffice the requirements of a family for complete one week. It can be group of only vegetables, only fruits or mix of both. Weekly boxes can be selected as per family need like small sized, medium sized or large sized. Customers also have liberty to change any ingredient in the box if they don’t use them or they can create customized boxes too according to their choice. </br></br>
With the motive of delivering fresh products, sabji on wheels understands the health concerns of individual and is aligned in providing chemical free products at very convenient prices. ‘Customer Satisfaction’ is the ultimate goal of sabji on wheels, therefore providing customers with same day free return of any faulty product. </br></br>
Coming from the founders, they believe ‘Gurgaon, being one of the most expensive & fastest growing cities in india’ has huge demand for reliable services to fulfil day to day consumer needs. Soon sabji on wheels won’t be limited to providing only sabjis to gurgaon but they would also be introducing various organic products like flour,juices,herbs through out NCR.</br></br>

Sabji On Wheels accepts orders over below mentioned modes:

Online  : www.sabjionwheels.com</br>
Email   : orders@sabjionwheels.com</br>
Phone   : +9 19310056669</br>
Whatsapp: +91 9310056669</br>



</div>

</div></div></div>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>
