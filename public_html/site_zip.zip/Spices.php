<? 
include_once("config.php");
$site_title="Spices";
?>
<!DOCTYPE HTML>
<html>
<head>
<title>High Grade Spices &amp; Spices Gurgaon</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="description" content="Spices best quality &amp; Spices at your doorstep directly with the best farmers in Gurgaon.">
<meta name="keywords" content="Spices, home delivery Spices, free delivery fruits in gurgaon, Spices at wholesale price in gurgaon">
<? include_once("commonTemplate/head.php")?>

<script>(function() {
  var _fbq = window._fbq || (window._fbq = []);
  if (!_fbq.loaded) {
    var fbds = document.createElement('script');
    fbds.async = true;
    fbds.src = '//connect.facebook.net/en_US/fbds.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(fbds, s);
    _fbq.loaded = true;
  }
  _fbq.push(['addPixelId', '1400018226953897']);
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', 'PixelInitialized', {}]);
</script>
<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=1400018226953897&amp;ev=NoScript" /></noscript>


</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
  <div class="feeback-heading">Spices</div>
  <div class="floating"><input type="button" value="Add to Cart" class="button add_to_cart_btn" id="button"  onClick="" />
   </div>
<div id="container">
	<div class="original-box proDetail" id="spice-1">
    <img src="img/s-1.JPG">
		<h2><strong>Chat Masala 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">46</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">42</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
		<div class="original-box proDetail" id="spice-2">
    <img src="img/s-1.JPG">
		<h2><strong>Chat Masala 50 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">24</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">22</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>

	<div class="original-box proDetail" id="spice-3">
    <img src="img/s-2.JPG">
		<h2><strong>Sabji Masala 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">40</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">36</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-4">
    <img src="img/s-3.JPG">
		<h2><strong>Jaljeera 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">46</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">42</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-5">
    <img src="img/s-4.JPG">
		<h2><strong>Methi Chutney 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">40</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">36</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-6">
    <img src="img/s-5.JPG">
		<h2><strong>Kesari Mirch 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">46</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">42</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
		<div class="original-box proDetail" id="spice-7">
    <img src="img/s-6.JPG">
		<h2><strong>Meat Masala 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">54</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">48</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>

	<div class="original-box proDetail" id="spice-8">
    <img src="img/s-7.jpg">
		<h2><strong>Tandoori Chicken Masala 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">54</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">48</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-9">
    <img src="img/s-8.jpg">
		<h2><strong>Kasoori Methi 25 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">26</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">23</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-10">
    <img src="img/s-9.jpg">
		<h2><strong>Sambhar Masala 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">50</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">45</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-11">
    <img src="img/s-10.jpg">
		<h2><strong>Pav Bhaji Masala 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">54</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">48</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
		<div class="original-box proDetail" id="spice-12">
    <img src="img/s-10.jpg">
		<h2><strong>Pav Bhaji Masala 50 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">28</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">25</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>

	<div class="original-box proDetail" id="spice-13">
    <img src="img/s-11.jpg">
		<h2><strong>Chana Masala 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">54</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">48</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-14">
    <img src="img/s-11.jpg">
		<h2><strong>Chana Masala 50 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">28</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">25</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-15">
    <img src="img/s-12.jpg">
		<h2><strong>Roasted Jeera Powder 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">46</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">42</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-16">
    <img src="img/s-13.jpg">
		<h2><strong>Garam Masala 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">70</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">63</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
		<div class="original-box proDetail" id="spice-17">
    <img src="img/s-13.jpg">
		<h2><strong>Garam Masala 50 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">38</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">34</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>

	<div class="original-box proDetail" id="spice-18">
    <img src="img/s-14.jpg">
		<h2><strong>Shahi Pulav Masala 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">120</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">108</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-19">
    <img src="img/s-15.JPG">
		<h2><strong>Black Pepper Powder 50 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">80</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">50</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-20">
    <img src="img/s-15.JPG">
		<h2><strong>Black Pepper Powder 8 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">10</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">9</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-21">
    <img src="img/s-16.jpg">
		<h2><strong>Dahi Bhalla Masala 50 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">28</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">25</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
		<div class="original-box proDetail" id="spice-22">
    <img src="img/s-17.JPG">
		<h2><strong>Kitchen King Masala 100 GMS</strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">54</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">48</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>

	<div class="original-box proDetail" id="spice-23">
    <img src="img/s-18.JPG">
		<h2><strong>South Meethi Chutney </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">15</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">13</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	<div class="original-box proDetail" id="spice-24">
    <img src="img/s-19.jpg">
		<h2><strong>Haldi/Turmeric Powder 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">22</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">20</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-25">
    <img src="img/s-19.jpg">
		<h2><strong>Haldi/Turmeric Powder 200 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">44</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">39</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-26">
    <img src="img/s-19.jpg">
		<h2><strong>Haldi/Turmeric Powder 500 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">110</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">99</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
	
	<div class="original-box proDetail" id="spice-27">
    <img src="img/s-20.jpg">
		<h2><strong>Mirchi/Chilly Powder 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">25</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">22</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-28">
    <img src="img/s-20.jpg">
		<h2><strong>Mirchi/Chilly Powder 200 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">50</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">46</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-29">
    <img src="img/s-20.jpg">
		<h2><strong>Mirchi/Chilly Powder 500 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">125</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">112</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>

	<div class="original-box proDetail" id="spice-30">
    <img src="img/s-21.jpg">
		<h2><strong>Mirchi/Chilly Kutti 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">25</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">22</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-31">
    <img src="img/s-21.jpg">
		<h2><strong>Mirchi/Chilly Kutti   200 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">50</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">46</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-32">
    <img src="img/s-21.jpg">
		<h2><strong>Mirchi/Chilly Kutti 500 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">125</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">112</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-33">
    <img src="img/s-22.jpg">
		<h2><strong>Super Garam Masala 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">38</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">34</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-34">
    <img src="img/s-22.jpg">
		<h2><strong>Super Garam Masala 200 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">65</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">59</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-35">
    <img src="img/s-22.jpg">
		<h2><strong>Special Garam Masala 200 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">60</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">54</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-36">
    <img src="img/s-23.jpg">
		<h2><strong>Dhaniya/Coriander Powder 200 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">52</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">47</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-37">
    <img src="img/s-23.jpg">
		<h2><strong>Dhaniya/Coriander Powder 500 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">140</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">125</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-38">
    <img src="img/s-24.jpg">
		<h2><strong>Amchoor/Dry Mango Powder 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">42</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">38</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-39">
    <img src="img/s-24.jpg">
		<h2><strong>Amchoor/Dry Mango Powder 200 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">80</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">72</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-40">
    <img src="img/s-25.jpg">
		<h2><strong>Anardana/Pomegranate Powder 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">55</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">49</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-41">
    <img src="img/s-26.jpg">
		<h2><strong>Pili/Yellow Chilly Powder 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">32</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">29</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-42">
    <img src="img/s-27.jpg">
		<h2><strong>Black Salt 200 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">18</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">16</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-43">
    <img src="img/s-28.jpg">
		<h2><strong>Lahori/Sendha Salt 200 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">12</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">11</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-44">
    <img src="img/s-29.jpg">
		<h2><strong>Lucknowi Saunf/Fennel 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">40</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">36</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-45">
    <img src="img/s-30.jpg">
		<h2><strong>Moti Saunf/Fennel 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">40</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">36</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-46">
    <img src="img/s-31.jpg">
		<h2><strong>Rai Whole 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">44</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">40</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-47">
    <img src="img/s-32.jpg">
		<h2><strong>Jeera Whole 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">40</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">36</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>

<div class="original-box proDetail" id="spice-48">
    <img src="img/s-32.jpg">
		<h2><strong>Jeera Whole 200 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">80</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">72</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-49">
    <img src="img/s-33.jpg">
		<h2><strong>Black Pepper Whole 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">150</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">135</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>

<div class="original-box proDetail" id="spice-50">
    <img src="img/s-34.jpg">
		<h2><strong>Yellow Mustard Seeds 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">22</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">20</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-51">
    <img src="img/s-35.jpg">
		<h2><strong>Black Mustard Seeds 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">25</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">22</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-52">
    <img src="img/s-36.jpg">
		<h2><strong>Methi Dana/Fenugreek 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">22</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">20</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-53">
    <img src="img/s-37.jpg">
		<h2><strong>Poppy Seeds 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">100</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">90</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-54">
    <img src="img/s-38.jpg">
		<h2><strong>Badi Elaichi 50 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">120</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">108</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>

<div class="original-box proDetail" id="spice-55">
    <img src="img/s-39.jpg">
		<h2><strong>Dalchini Whole 50 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">28</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">25</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>

<div class="original-box proDetail" id="spice-56">
    <img src="img/s-40.jpg">
		<h2><strong>Ajwain Whole 100 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">40</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">36</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>
<div class="original-box proDetail" id="spice-57">
    <img src="img/s-41.jpg">
		<h2><strong>Hing 10 GMS </strong></h2>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">45</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">40</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
	</div>






</div><!-- #container --> </div>
 </div>
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>