<? 
include_once("config.php");
$site_title="Flour";
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Gift Fruit Baskets &amp; Vegetables Gurgaon</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="description" content="Fruit basket with fresh and best quality fruits &amp; vegetables at your doorstep directly with the best farmers in Gurgaon.">
<meta name="keywords" content="Weekly box, home delivery vegetables, free delivery fruits in gurgaon, sabji market gurgaon, marriage fruit basket, fruit basket ">

<? include_once("commonTemplate/head.php")?>
</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
  <div class="feeback-heading">SPECIALS FRUITS GIFT BASKETS</div>
  <div class="floating"><input type="button" value="Add to Cart" class="button add_to_cart_btn" id="button"  onClick="" />
   </div>
<div id="container">
	<div class="original-box2 proDetail" id="Basket-1"><h2><strong>Fruit Basket Mini</strong></h2>
    <img width="170" height="170" src="img/fb12.jpg"><br><img width="136" height="25" src="img/box-1-2.gif"><br>

PRICE:Rs<span class="s_pirce"> 449.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
6 Types of Fresh Fruits

		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>
1. Apple Indian 2Piece  <br>
2. Apple Golden 2Piece <br>
3. Orange Imported 2Piece <br>
4. Babugosha High Grade 2Piece <br>
5. Nashpati Imported 2Piece   <br>
6. Pomegranate 1Piece<br>
		</div>
	</div>
	<div class="original-box2 proDetail" id="Basket-2"><h2><strong>Fruit Basket Medium
</strong></h2>
    <img width="170" height="170" img src="img/fb12.jpg"><br>
 <img width="108" height="25" src="img/box-2-3.gif"><br>
 PRICE:Rs<span class="s_pirce"> 849.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
     8 Types of High Grade Fruits



		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>

1. Apple Fuji 2Piece  <br>
2. Apple Golden 2Piece <br>
3. Orange Imported 2Piece <br>
4. Babugosha High Grade 2Piece <br>
5. Nashpati Imported 2Piece   <br>
6. Pomegranate 2Piece<br>
7. Custard Apple 1Piece<br>
8.Pinapple High Grade 1Piece<br>

		</div>
	</div>
	<div class="original-box2 proDetail" id="Basket-3"><h2><strong>Fruit Basket Large</strong></h2>
    <img width="170" height="170" img src="img/fb12.jpg"><br>
 <img width="91" height="25" src="img/box-3-5.gif"><br>
 PRICE:Rs <span class="s_pirce">1100.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
 
 	12 Types of Imported Fruits.



		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>
 
1. Apple Fuji 2Piece  <br>
2. Apple Green 2Piece<br>
3. Apple Golden 2Piece <br>
4. Apple Indian 2Piece<br>
5. Custard Apple 2Piece<br>
6. Dates Imported 250 GMS<br>
7. Apricot 250 GMS<br>
8. Orange Imported 2Piece <br>
9. Babugosha High Grade 2Piece <br>
10. Nashpati Imported 2Piece   <br>
11. Pomegranate 2Piece<br>
12.Pinapple High Grade 1Piece<br>
		</div>
	</div>
<hr>
	<div class="original-box2 proDetail" id="Basket-6"><h2><strong>SPECIAL MARRIAGE FRUIT BASKET<br> (21 KG MIX FRUITS)</strong></h2>
    <img width="250" height="220" img src="img/MFB11.jpg"><br>
 
 PRICE:Rs <span class="s_pirce">5100.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div> 
 	



		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>
 
Apple Washington (5 KG) <br>
Apple Kinnour (5 KG) <br>
Dates Crown (5 Packet) <br>
Orange Malta (5 KG) <br>
Strawberry (5 Packet ) <br>
Apricot (2 Packet) <br>
Pomegranate (2 KG) <br> 
</div>
		</div>


	<div class="original-box2 proDetail" id="Basket-5"><h2><strong>SPECIAL MARRIAGE FRUIT BASKET<br> (30 KG MIX FRUITS)</strong></h2>
    <img width="250" height="220" img src="img/MFB11.jpg"><br>
 
 PRICE:Rs <span class="s_pirce">8100.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
 



		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>
Strawberry (10 Packet ) <br>
Apricot (5 Packet) <br> 
Apple Washington (5 KG) <br>
Apple Green (5 KG) <br>
Apple Kinnour (5 KG) <br>
Black Grapes (5 Box) <br>
Orange Malta (5 KG) <br>
Pomegranate (5 KG) <br>

</div>

		</div>


	<div class="original-box2 proDetail" id="Basket-4"><h2><strong>SPECIAL MARRIAGE FRUIT BASKET<br> (35 KG IMPORTED FRUITS)</strong></h2>
    <img width="250" height="220" img src="img/MFB11.jpg"><br>
 
 PRICE:Rs <span class="s_pirce">11000.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
 
 	


		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>

Strawberry (10 Packet ) <br> 
Apple - Fuji (10 KG) <br>
Kiwi (20 Piece) <br>
Babugosha USA (5 KG) <br>
Pomegranate (5 KG) <br>
Orange Malta (5 KG) <br>
Plums Imported (2 KG) <br>
Apricot (5 Packet) <br>
Dates Crown (5 Packet) <br>
		</div>
		</div>


</div><!-- #container --> </div>
 </div>
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>
