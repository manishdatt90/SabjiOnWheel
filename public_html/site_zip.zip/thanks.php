<? include_once("config.php");
$site_title="Thanks";
?> 
<!DOCTYPE HTML>
<html>
<head>
<title>Thanks for Order Fruits &amp; Vegetables Gurgaon</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="description" content="Thanks for Order fresh and best quality fruits &amp; vegetables at your doorstep directly with the best farmers in Gurgaon.">
<meta name="keywords" content="Order, home delivery vegetables, free delivery fruits in gurgaon, sabji market gurgaon">
<? include_once("commonTemplate/head.php")?> 

</head>

<body>
<? include_once("commonTemplate/header.php")?> 
<div class="feedback-outer">
  <div class="feedback-inner">
  <div class="feeback-heading">Thanks</div>
  <br><img src="img/thanks.png" align="middle" class="img-size" />
  </div>
 </div>
</section>
<? include_once("commonTemplate/footer.php")?>

</body>
</html>
