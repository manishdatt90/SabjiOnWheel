<? include_once("config.php");
$site_title="How To Order";
?>
<!DOCTYPE HTML>
<html>
<head>
<title>How to Order Fruits &amp; Vegetables Gurgaon</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="description" content="Order fresh and best quality fruits &amp; vegetables at your doorstep directly with the best farmers in Gurgaon.">
<meta name="keywords" content="online orders, home delivery vegetables, free delivery fruits in gurgaon, sabji market gurgaon">
<? include_once("commonTemplate/head.php")?>


<script>(function() {
  var _fbq = window._fbq || (window._fbq = []);
  if (!_fbq.loaded) {
    var fbds = document.createElement('script');
    fbds.async = true;
    fbds.src = '//connect.facebook.net/en_US/fbds.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(fbds, s);
    _fbq.loaded = true;
  }
  _fbq.push(['addPixelId', '1400018226953897']);
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', 'PixelInitialized', {}]);
</script>
<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=1400018226953897&amp;ev=NoScript" /></noscript>

</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
 <div class="feedback-outer">
  <div class="feedback-inner">
<div class="feedback-left2">
<div class="feeback-heading">How to Order Products from SABJI ON WHEELS? JUST FOLLOW<br>
 EASY STEPS.</div>
<div class="left-cl-div"><div style="color:#548dd4;" class="how-order">STEP 1<br><br>



Call Us at +91-9310056669<br>

Or Email Us at orders@sabjionwheels.com<br>

Or Register online and place your orders<br>
<br>

</div>
<div style="color:#f99646;" class="how-order">STEP 2<br><br>


In the call/Email, Indicate to us:<br>

ITEM NAME<br>

QUANTITY<br>

Repeat step 2 if you are buying more than 1 item

<br>
<br>

</div>
<div style="color:#84181d;" class="how-order">STEP 3<br><br>

Indicate to us:<br>

Your Name<br>

Your complete Address<br>

Nearby Landmark<br>

Delivery Day &amp; Time
<br>
<br>
<br>


</div>
<div style="color:#a08256;" class="how-order">STEP 4<br><br>



We will deliver your order on your address as per your instructions. Thanks.

</div></div>
<div class="right-cl-div">
<div class="feedback-right3"><img width="130" height="132" style="float:right" alt="step" src="img/step1.jpg"></div>
<div class="feedback-right3"><img width="135" height="133" style="float:right" alt="step" src="img/step2.jpg"></div>
<div class="feedback-right3"><img width="142" height="133" style="float:right" alt="step" src="img/step3.jpg"></div>
<div class="feedback-right3"><img width="113" height="133" style="float:right" alt="step" src="img/step4.jpg"></div>
 </div></div>

<iframe src='http://www.flipkart.com/affiliate/displayWidget?affrid=WRID-142178506309337368' frameborder=0 height=90 width=728></iframe>

</div>
 </div>
  
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>
