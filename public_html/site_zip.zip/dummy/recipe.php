<? include_once("config.php");
$site_title="Recpie";
?>
<!DOCTYPE HTML>
<html>
<head>
<? include_once("commonTemplate/head.php")?>
</head>

<body>
<? include_once("commonTemplate/header.php")?>
<div class="feedback-outer">
  <div class="feedback-inner">
  <div class="feeback-heading">
<span style="font-family:Jokerman; font-size:26px; line-height:6px;color:#c0504d; ">RECIPE</span><br>
<a href="http://www.sanjeevkapoor.com/bharwan-parwal.aspx">1. Bharwa Parwal</a><br>
<a href="http://www.prestigesmartchef.com/recipe/view/masaledar-kundru">2. Masaledar - Kundru</a><br>
<a href="http://www.sanjeevkapoor.com/Bhindi-Amchur-FoodFood.aspx">3. Bhindi Amchur</a><br>
<a href="http://www.sanjeevkapoor.com/Baked-Potato-Salad.aspx">4. Baked Potato Salad</a><br>
<a href="http://www.sanjeevkapoor.com/Aloo-Paneer-and-Broccoli-Makhni-FoodFood.aspx">5. Aloo, Paneer and Broccoli Makhni</a><br>
<a href="http://www.sanjeevkapoor.com/Anari-Vegetable-Kofta-FoodFood.aspx">6. Anari Vegetable Kofta</a><br>
<a href="http://www.sanjeevkapoor.com/Pumpkin-Pav-Bhaji-FoodFood.aspx">7. Pumpkin Pav Bhaji</a><br>
<a href="http://http://www.sanjeevkapoor.com/Paneer-Pudina-Kalimirch-FoodFood.aspx">8. Paneer Pudina Kalimirch</a><br>
</div>
 </div>
 </div>
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>
