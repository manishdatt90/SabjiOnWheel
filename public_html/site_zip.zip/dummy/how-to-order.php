<? include_once("config.php");
$site_title="How To Order";
?>
<!DOCTYPE HTML>
<html>
<head>
<? include_once("commonTemplate/head.php")?>
</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
 <div class="feedback-outer">
  <div class="feedback-inner">
<div class="feedback-left2">
<div class="feeback-heading">How to Order Products from SABJI ON WHEELS? JUST FOLLOW<br>
 EASY STEPS.</div>
<div class="left-cl-div"><div style="color:#548dd4;" class="how-order">STEP 1<br><br>



Call Us at +91-9310056669<br>

Or Email Us at orders@sabjionwheels.com<br>
<br>

</div>
<div style="color:#f99646;" class="how-order">STEP 2<br><br>


In the call/Email, Indicate to us:<br>

ITEM NAME<br>

QUANTITY<br>

Repeat step 2 if you are buying more than 1 item

<br>
<br>

</div>
<div style="color:#84181d;" class="how-order">STEP 3<br><br>

Indicate to us:<br>

Your Name<br>

Your complete Address<br>

Nearby Landmark<br>

Delivery Day &amp; Time
<br>
<br>
<br>


</div>
<div style="color:#a08256;" class="how-order">STEP 4<br><br>



We will deliver your order on your address as per your instructions. Thanks.

</div></div>
<div class="right-cl-div">
<div class="feedback-right3"><img width="130" height="132" style="float:right" alt="step" src="img/step1.jpg"></div>
<div class="feedback-right3"><img width="135" height="133" style="float:right" alt="step" src="img/step2.jpg"></div>
<div class="feedback-right3"><img width="142" height="133" style="float:right" alt="step" src="img/step3.jpg"></div>
<div class="feedback-right3"><img width="113" height="133" style="float:right" alt="step" src="img/step4.jpg"></div>
 </div></div>

</div>
 </div>
  
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>
