<? 
include_once("config.php");
$site_title="Flour";
?>
<!DOCTYPE HTML>
<html>
<head>
<? include_once("commonTemplate/head.php")?>
</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
  <div class="feeback-heading">ORGANIC FLOURS</div>
  <div class="floating"><input type="button" value="Add to Cart" class="button add_to_cart_btn" id="button"  onClick="" />
   </div>
<div id="container">
	<div class="original-box proDetail" id="Flour-1">
    <img src="img/FLR-1.jpg">
		<h2><strong>Organic Besan</strong></br>500 GM</h2>
PRICE: Rs <span class="s_pirce">72.00</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		<div class="popup-box popup-box-left">
			<strong>Products:</strong><br>
Organic Besan </br>
Pesticide Free

		</div>
	</div>
	<div class="original-box proDetail" id="Flour-2">
    <img src="img/FLR-2.jpg">
		<h2><strong>ORGANIC CORN FLOUR</br>500 GMS</strong></h2>
PRICE: Rs <span class="s_pirce">40</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		<div class="popup-box popup-box-left">
			<br>
ORGANIC CORN FLOUR
		</div>
	</div>
	<div class="original-box proDetail" id="Flour-3">
    <img src="img/FLR-3.jpg">
		<h2><strong>ORGANIC RAGI FLOUR</br>500 GMS</strong></h2>
PRICE: Rs <span class="s_pirce">48</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		<div class="popup-box popup-box-left">
			<strong>Description</strong><br>

		</div>
	</div>
	<div class="original-box proDetail" id="Flour-4">
    <img src="img/FLR-4.jpg">
		<h2><strong>ORGANIC RICE FLOUR </br>500 GMS</strong></h2>
PRICE: Rs <span class="s_pirce">38.00</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		<div class="popup-box popup-box-left">
			<strong>Products:</strong><br>

		</div>
	</div>
	<div class="original-box proDetail" id="Flour-5">
    <img src="img/FLR-5.jpg">
		<h2><strong>ORGANIC WHEAT FLOUR</br>5 KG</strong></h2>
PRICE: Rs <span class="s_pirce">245.00</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		<div class="popup-box popup-box-left">
			<strong>Products:</strong><br>


		</div>
	</div>
	<div class="original-box proDetail" id="Flour-6">
    <img src="img/FLR-6.jpg">
		<h2><strong>ORGANIC WHEAT FLOUR</br> 1 KG</strong></h2>
PRICE:Rs <span class="s_pirce">50.00</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		<div class="popup-box popup-box-left">
			<strong>Products:</strong><br>

		</div>
	</div>
	<div class="original-box proDetail" id="Flour-7">
    <img src="img/FLR-7.jpg">
		<h2><strong>ORGANIC WHEAT MAIDA</br> 1 KG</strong></h2>
PRICE: Rs <span class="s_pirce">68.00</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		<div class="popup-box popup-box-left">
			<strong>Products:</strong><br>

		</div>
	</div>
	<div class="original-box proDetail" id="Flour-8">
    <img src="img/FLR-8.jpg">
		<h2><strong>ORGANIC WHEAT MAIDA</br> 500 GM</strong></h2>
PRICE: Rs <span class="s_pirce">35.00</span>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		<div class="popup-box popup-box-left">
			<strong>Products:</strong><br>

		</div>
	</div>
	</div>
</div><!-- #container --> </div>
 </div>
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>
