<? include_once("config.php");
$site_title="Weekly";
?>
<!DOCTYPE HTML>
<html>
<head>
<? include_once("commonTemplate/head.php")?> 

</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
   <div class="feeback-heading2"><div class="top-left-box"><h3>About the Boxes</h3><br>
<div class="floating"><input type="button" value="Add to Cart" class="button add_to_cart_btn" id="button"  onClick="" /></div>

<span>WHY BOXES?</span><br>

We plan each box to give you a healthy variety of flavours and nutrients.<br>
 
<span>PARTICULAR PREFERENCES?</span> <br>

Just tell us if there's any fruit or veg you won't use and we'll send you something else instead.<br>

<span>WHAT IF I AM NOT IN?</span><br>

Everytime we place your order, we confirm you your preferred delivery date and time.<br>

<span>WHAT IF ANY PRODUCT IS OF BAD QUALITY?</span><br>

We will replace your whole box without any question and will deliver the new box.
</div><img align="right" src="img/organice.jpg"></div>

<div id="container">
	<div class="original-box2" id="week-1"><h2><strong>VEGETABLE BOXES</strong></h2>
    <img src="img/b1.jpg"><br>Full of Seasonal fresh &amp; <br>Healthy Vegetables.
</div>
	<div class="original-box2" id="week-2"><h2><strong>FRUIT BOXES</strong></h2>
    <img src="img/b2.jpg"><br>Full of Seasonal fresh<br> &amp;  healthy
variety of Fruits<br> for all size of families.
	</div>
	<div class="original-box2 id="week-3"><h2><strong>MIXED BOXES</strong></h2>
    <img src="img/b3.jpg"><br>Full of seasonal fruits<br> &amp; vegetables
 freshly packed <br>only for you.</div>
    <hr>
	<div class="original-box2 proDetail" id="week-4"><h2><strong>Large Veg Box</strong></h2>
    <img width="190" height="190" src="img/b4.jpg"><br><img width="136" height="25" src="img/box-3-5.gif"><br>

PRICE:Rs<span class="s_pirce"> 849.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
15 Types of seasonal Vegetables.

		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>
1. CABBAGE 2KG  <br>
2. CAULIFLOWER 2 KG <br>
3. CAPSICUM 1.5 KG <br>
4. ONION 3 KG <br>
5. POTATO 3 KG <br>
6. Tomato 2 KG   <br>
7. GINGER 250 GMS <br>
8. PEAS 1 KG  <br>
9. BEANS 1 KG        <br>
10. CORINDER 200 GMS     <br>
11. BRINJAL 1 KG         <br>
12. CUCUMBER 2 KG        <br>
13. GARLIC 250 GMS      <br>
14. LEMON 500 GMS        <br>
15. LADY FINGER 1 KG     <br>         
		</div>
	</div>
	<div class="original-box2 proDetail" id="week-5"><h2><strong>Medium Veg Box</strong></h2>
    <img src="img/b5.jpg"><br>
 <img width="108" height="25" src="img/box-2-3.gif"><br>
 PRICE:Rs<span class="s_pirce"> 549.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
     12 Types of seasonal Vegetables



		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>
1. CAULIFLOWER & CABBAGE (2 KG MIX)   <br>
2. CAPSICUM 1KG       <br>
3. ONION 2 KG          <br>
4. POTATO 3 KG         <br>
5. Tomato 1 KG          <br>
6. GINGER 250 GMS       <br>
7. PEAS 500 GMS           <br>
8. CORINDER 200 GMS    <br>
9. CUCUMBER 2 KG        <br>
10. GARLIC 250 GMS       <br>
11. LEMON 250 GMS        <br>
12. LADY FINGER 1 KG     <br>


		</div>
	</div>
	<div class="original-box2 proDetail" id="week-6"><h2><strong>Small Veg Box</strong></h2>
    <img src="img/b6.jpg"><br>
 <img width="91" height="25" src="img/box-1-2.gif"><br>
 PRICE:Rs <span class="s_pirce">279.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
 
 	10 Types of seasonal Vegetables.



		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>
 
1. CAPSICUM 500 GMS     <br>
2. Cauliflower 1 KG <br>
3. ONION 1 KG           <br>
4. POTATO 1 KG          <br>
5. Tomato 1 KG           <br>
6. Parwal  500 GMS              <br>
7. PEAS 500 GMS            <br>
8. CORINDER 100 GMS    <br>
9. CUCUMBER 1 KG        <br>
10. Garlic 250 GMS      <br>

		</div>
	</div>
       <hr>
	<div class="original-box2 proDetail" id="week-7"><h2><strong>Large Fruit Box</strong></h2>
    <img src="img/b7.jpg"><br>
<img width="136" height="25" src="img/box-3-5.gif"><br>
PRICE:Rs <span class="s_pirce">1449.00</span><br>
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
10 Types of seasonal Fresh Fruits.



		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>

1. Apple Washington 1KG<br>
2. Bananas 1 Dozen<br>
3. Chikoo 1KG<br>
4. Mango Safeda 2 KG<br>
5. Kiwi 6 Piece<br>
6. Mausambi 2KG<br>
7 Pomegranate 1KG<br>
8 Babugosha IMPORTED 1KG<br>
9 Pineapple High Grade 2 Piece<br>
10. Piece Papaya 1 Medium Piece<br>


		</div>
	</div>
	<div class="original-box2 proDetail" id="week-8"><h2><strong>Medium Fruit Box</strong></h2>
    <img src="img/b8.jpg">
		<br>

 <img width="108" height="25" src="img/box-2-3.gif"><br>
 PRICE:Rs <span class="s_pirce">799.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
Fresh Fruits Box for Small Families.

		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>

1. Apple Washington 1KG<br>
2. Bananas 1 Dozen<br>
3. chikoo 1 KG<br>
4. Mango Safeda 2 KG<br>
5. Kiwi 3 Piece<br>
6. Mausambi 1KG<br>
7. Pomegranate 500 GMS<br>
8. Papaya 1 Piece<br>

		</div>
	</div>
	<div class="original-box2 proDetail" id="week-9"><h2><strong>Small Fruit Box</strong></h2>
    <img src="img/b9.jpg"><br> 
 <img width="91" height="25" src="img/box-1-2.gif"><br>
 PRICE:Rs<span class="s_pirce"> 425.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
Fresh Fruit Box for Singles



		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>

1. Apple Washington 500 GMS<br>
2. Bananas Half Dozen<br>
3. Mango Safeda 1 KG<br>
4. Kiwi 2 Piece<br>
5. Mausambi 1KG<br>
6. Pomegranate 500 GMS<br>


		</div>
	</div>
       <hr>
	<div class="original-box2 proDetail" id="week-10"><h2><strong>Large Mixed Box</strong></h2>
    <img src="img/b10.jpg"><br>
 <img width="136" height="25" src="img/box-3-5.gif"><br>
 PRICE:Rs<span class="s_pirce"> 1475.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
17 Types of seasonal Fruits & Vegetables.

	<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>
1. CAULIFLOWER 2 KG <br>
2. CAPSICUM 1 KG <br>
3. ONION 3 KG 
4. POTATO 2 KG <br>
5. Tomato 2 KG   <br>
6. GINGER 250 GMS <br>
7. PEAS 1 KG  
8. CORINDER 200 GMS     <br>
9. CUCUMBER 2 KG        <br>
10. LEMON 250 GMS        <br>
11. Lady Finger 1 KG        <br>
12. Apple Washington 1KG<br>
13. Bananas 1 Dozen<br>
14. Kiwi 6 Piece<br>
15. Mango Safeda 2 KG<br>
16 Pomegranate 1KG<br>
17. Piece Papaya 1KG<br>


		</div>
	</div>
	<div class="original-box2 proDetail" id="week-11"><h2><strong>Medium Mixed Box</strong></h2>
    <img src="img/b11.jpg"><br>

 <img width="108" height="25" src="img/box-2-3.gif"><br>
 PRICE:Rs <span class="s_pirce">999.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
13 Types of seasonal Fresh Fruits & Vegetables.


		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>
1. CAULIFLOWER 1 KG <br>
2. CAPSICUM 1 KG <br>
3. ONION 2 KG 
4. POTATO 1 KG <br>
5. Tomato 1 KG   <br>
6. GINGER 250 GMS <br>
7. CUCUMBER 1 KG        <br>
8. Lady Finger 1 KG        <br>
9. Apple Washington 1KG<br>
10. Bananas 1 Dozen<br>
11. Kiwi 5 Piece<br>
12. Mango Safeda 2 KG<br>
13 Pomegranate 500 GMS<br>
		</div>
	</div>
	<div class="original-box2 proDetail" id="week-12"><h2><strong>Small Mixed Box</strong></h2>
    <img src="img/b12.jpg"><br><img width="91" height="25" src="img/box-1-2.gif"><br>
    PRICE:Rs <span class="s_pirce">489.00
    </span>
<br> 
<div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
13 Types of seasonal Vegetables & Fruits.


		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>
1. CAULIFLOWER 500 GMS <br>
2. CAPSICUM 500 GMS <br>
3. ONION 1 KG 
4. POTATO 500 GMS <br>
5. Tomato 500 GMS <br>
6. CUCUMBER 500 GMS        <br>
7. Beans 250 GMS        <br>
8. Lady Finger 500 GMS      <br>
9. Lemon - 200 GMS
10. Apple Washington 500 GMS<br>
11. Bananas 6 Piece<br>
12. Mango Safeda 1 KG<br>
13. Pomegranate 500 GMS<br>

		</div>
	</div>
	

</div> <div style="clear:both;"></div></div>
 </div>
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>