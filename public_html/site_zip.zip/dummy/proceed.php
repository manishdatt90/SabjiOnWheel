<style>
.custom-font-1.trans-1 > span {
    margin-bottom: 10px;
    margin-left: 10px;
}

#fancybox-content span {
    width:39%;
}

</style>
<div class="light-box">
<span>
 <a class="button-3 custom-font-1 trans-1" href="cart.php"><span>Proceed to checkout</span></a>
</span>
<span>
 <a class="button-3 custom-font-1 trans-1" href="vegetables.php"><span>Continue Shopping to Vegetables</span></a>
</span>
<span>
 <a class="button-3 custom-font-1 trans-1" href="fruits.php"><span>Continue Shopping to Fruits</span></a>
</span>
<span>
 <a class="button-3 custom-font-1 trans-1" href="weekly.php?ref=cart"><span>Continue Shopping to Weekly Boxes</span></a>
</span>
<span>
 <a class="button-3 custom-font-1 trans-1" href="health.php?ref=cart"><span>Continue Shopping to Health Boxes</span></a>
</span>
</div>
																				
