<div style="clear:both;"></div>
<section>
<footer>
<div class="footer">
<!-- start of wrapper -->
<div class="wrapper">
<!-- start of row5 -->
<div class="row5">

<div class="row51">
<div class="row51i"></div>
<br>
<span class="hhh2">Let's connect with us &amp; discuss further</span>
<p>Tell us about requirements and we will get back to you as soon as possible.</p>
</div>


<div class="row52"><a href="<?=$site_url?>/login/">Register Now</a></div>

<!-- start of row53 -->
<div class="row53">
<div class="row531">Need Assistance ?</div>
<div class="row532">
<div class="row532i"></div>

  <div class="row532t">+ 91 - 931-005-6669 (India)</div>
</div>
<div class="row533">
<div class="row533i"></div>
  <div class="row533t"><a href="mailto:orders@sabjionwheels.com">orders@sabjionwheels.com</a></div>
</div>
</div>
<!-- end of row53 -->
<div style="clear:both;"></div>
</div>
<!-- end of row5 -->
</div>
<!-- end of wrapper -->
<div class="clrr"></div>
</div>
  <div class="footer-outer">
    <div class="footer-inner">
     
      <div class="footer-bar">
        <ul>
          <li><a href="<?=$site_url?>/vegetables.php">VEGETABLES</a></li>
          <li><a href="<?=$site_url?>/fruits.php">FRUITS</a></li>
          <li><a href="<?=$site_url?>/weekly.html">WEEKLY BOXES</a></li>
          <li><a href="<?=$site_url?>/health.html">HEALTH BOXES</a></li>
          <li><a href="<?=$site_url?>/recipe.html">RECIPE</a></li>
          <li><a href="<?=$site_url?>/offer.html">OFFERS</a></li>
        </ul>
      </div>
    </div>
     <div class="copyright">
<strong>Designed &amp; Developed by <a href="http://www.seotechexperts.in/" target="_blank">SEO Tech Experts</a></strong>
Copyright <strong>Sabji On Wheels</strong>. All Rights are Reserved.
</div>
  </div>
</footer>
</section>
<script src="<?=$site_url?>/js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
$('#layerslider').layerSlider({
skinsPath : '<?=$site_url?>layerslider/skins/',
skin : 'fullwidth',
thumbnailNavigation : 'hover',
hoverPrevNext : true,
responsive : true,
responsiveUnder :940,
thumbnailNavigation : false,
sublayerContainer : 1000
});
});		
</script>