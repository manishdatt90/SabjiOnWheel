<? include_once("config.php");
$site_title="Offer";
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Offers for Fruits &amp; Vegetables Gurgaon</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="description" content="Best Offers for fresh and best quality fruits &amp; vegetables at your doorstep directly with the best farmers in Gurgaon.">
<meta name="keywords" content="best offer, home delivery vegetables, free delivery fruits in gurgaon, sabji market gurgaon">
<? include_once("commonTemplate/head.php")?>


<script>(function() {
  var _fbq = window._fbq || (window._fbq = []);
  if (!_fbq.loaded) {
    var fbds = document.createElement('script');
    fbds.async = true;
    fbds.src = '//connect.facebook.net/en_US/fbds.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(fbds, s);
    _fbq.loaded = true;
  }
  _fbq.push(['addPixelId', '1400018226953897']);
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', 'PixelInitialized', {}]);
</script>
<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=1400018226953897&amp;ev=NoScript" /></noscript>

</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
<div class="divbox-left">
<div class="feeback-heading" style="color:#C0504D">Monthly Discounts:</div>
<div class="how-order" style="color:#548dd4;">
<ul type="circle">
<li style="color:#948a54;">If your order reach Rs.1000 or more, you will get 5% Off on the total bill.**(Not included Boxes)</li>
<li style="color:#c0504d;">For advance orders you will get 5% Off on the total bill.** (For example: If you need delivery on 10th May and you placed your order on 9th May then you will get 5% off on the total bill.)(Discount will appear at the time of delivery of your order in the printed invoice copy.)</li>
<li style="color:#9bbb59;"> NOTE: Maximum Discount Limit is Rs. 200 on all the Offers.</li>

</ul>
</div>
<div class="how-order">

<div class="feeback-heading" style="color:#C0504D">Referral Discounts:</div>

Refer our services to your friends. You will get 5% off on your next order with us. 
Just follow the steps and have 5% off on your next order with us:


<br>
<br>

</div>
<div class="how-order" style="color:#1f497d;">Process:

<ul type="circle">
<li style="color:#1f497d;">Step 1: Just refer our services to your friends.</li>
<li style="color:#c03535;">Step 2:  Ask your friends to mention your name &amp; Mobile number to us while placing orders.</li>
<li style="color:#225990;">Step 3: SABJI ON WHEELS will make a note of your referral and feed in the system.</li>
<li style="color:#00b050;">Step 4:You will get 5% discount on your next order with us. Just mention your friend's name to whom you referred our services.</li>
<li style="color:#1f497d;">STEP 5: Our Customer care executive will check in the system and will provide you your discounts.</li>
</ul>


</div>


</div>
<div class="divbox-right"><img src="img/offer1.jpg" width="275" height="204" alt="offer" style="float:right"></div>
<div class="divbox-right"><img src="img/offer2.jpg" width="275" height="204" alt="offer" style="float:right"></div>
<div class="divbox-right"><img src="img/offer3.jpg" width="275" height="204" alt="offer" style="float:right"></div>
<iframe src='http://www.flipkart.com/affiliate/displayWidget?affrid=WRID-142178506309337368' frameborder=0 height=90 width=728></iframe>
 </div>
 </div>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>
