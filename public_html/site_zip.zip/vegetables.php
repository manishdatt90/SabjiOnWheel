<? include_once("config.php")?>
<!DOCTYPE HTML>
<html><head>
<title>Free Home Delivery Vegetables Gurgaon|Buy Online</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="keywords" content="home delivery vegetables, buy online vegetable in gurgaon, sabji market gurgaon">
<meta name="description" content="Sabji On Wheels delivers fresh and best quality vegetables at your doorstep directly with the best farmers buy online Gurgaon.">
<? include_once("commonTemplate/head.php")?>  



<!-- Facebook Conversion Code for Leads -->

<script>(function() {

var _fbq = window._fbq || (window._fbq = []);

if (!_fbq.loaded) {

var fbds = document.createElement('script');

fbds.async = true;

fbds.src = '//connect.facebook.net/en_US/fbds.js';

var s = document.getElementsByTagName('script')[0];

s.parentNode.insertBefore(fbds, s);

_fbq.loaded = true;

}

})();

window._fbq = window._fbq || [];

window._fbq.push(['track', '6015085393536', {'value':'0.00','currency':'INR'}]);

</script>

<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?ev=6015085393536&amp;cd[value]=0.00&amp;cd[currency]=INR&amp;noscript=1" /></noscript>



</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
  <div class="feeback-heading">Vegetables</div>
   <div class="floating" ><input type="button" value="Add to Cart"  class="button add_to_cart_btn" id="button"/></div>
<form name="frmAddToCart" id="frmAddToCart" action="/addtocart.php" method="post">
<input name="cart" type="hidden" id="cart" value="1" />
<table width="100%" cellspacing="0" cellpadding="0" border="1" class="td-style">
  <tbody><tr>
    <td width="50%" valign="top" align="left">
    <table width="100%" cellspacing="0" cellpadding="0" border="0" class="td-style2">
    <tbody>


<tr class="proDetail" id="veg-94">
        <td valign="top" align="left"><img width="104" height="93" src="img/CRT11.jpg"></td>
        <td valign="middle" align="center"><strong>2 KG Carrot @ Rs. 59 <br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">72</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">59</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>






<tr class="proDetail" id="veg-92">
        <td valign="top" align="left"><img width="104" height="93" src="img/CH11.jpg"></td>
        <td valign="middle" align="center"><strong>Green Chickpeas - Choliye (200 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">45</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">40</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>


<tr class="proDetail" id="veg-71">
        <td valign="top" align="left"><img width="104" height="93" src="img/PN11.JPG"></td>
        <td valign="middle" align="center"><strong>Paneer (200 GMS Packet)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">60</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">60</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>

<tr class="proDetail" id="veg-74">
        <td valign="top" align="left"><img width="104" height="93" src="img/FP11.jpg"></td>
        <td valign="middle" align="center"><strong>FRESH PANEER (250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">75</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">70</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>

<tr class="proDetail" id="veg-97">
        <td valign="top" align="left"><img width="104" height="93" src="img/v49.jpg"></td>
        <td valign="middle" align="center"><strong>TOMATO - Desi (500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">20</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">17</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>


<tr class="proDetail" id="veg-48">
        <td valign="top" align="left"><img width="104" height="93" src="img/v49.jpg"></td>
        <td valign="middle" align="center"><strong>TOMATO - Bombay (500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">25</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">23</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>

<tr class="proDetail" id="veg-67">
        <td valign="top" align="left"><img width="104" height="93" src="img/A11.jpg"></td>
        <td valign="middle" align="center"><strong>Amla (250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">17</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">14</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
          

<tr class="proDetail" id="veg-90">
    <td valign="top" align="left"><img width="104" height="93" src="img/PC11.jpg"></td>
    <td valign="middle" align="center"><strong>POTATO-Chilke Wala(500 GM)</strong><br>
       <span class="org-text"><strike> MARKET PRICE: Rs</strike><span class="market_pirce">10</span></span> <br>
                             SABJIONWHEELS PRICE: Rs<span class="s_pirce"> 8</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>

  <tr  class="proDetail" id="veg-2">
    <td valign="top" align="left"><img width="104" height="93" src="img/v25.jpg"></td>
    <td valign="middle" align="center"><strong>POTATO- BABY POTATO(500 GM) </strong><br>
       <span class="org-text"><strike> MARKET PRICE: Rs</strike> <span class="market_pirce">24</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">20</span>
       <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
 <tr class="proDetail" id="veg-18">
    <td valign="top" align="left"><img width="104" height="93" src="img/v17.jpg"></td>
    <td valign="middle" align="center"><strong>KARELA-DESI (250 GMS)</strong><br>
       <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">28</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">25</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
 <tr class="proDetail" id="veg-19">
    <td valign="top" align="left"><img width="104" height="93" src="img/v18.jpg"></td>
    <td valign="middle" align="center"><strong>LADY FINGER(BHINDI)(250 GMS)</strong><br>
         <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">30</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">28</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
 
  <tr class="proDetail" id="veg-4">
    <td valign="top" align="left"><img width="104" height="93" src="img/v2.jpg"></td>
    <td valign="middle" align="center"><strong>CABBAGE - ORGANIC(700-750 GMS)</strong>
<br>
      <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">30</span></span> <br>
     SABJIONWHEELS PRICE: Rs <span class="s_pirce">24</span>
       <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>     </td>
  </tr>
  <tr class="proDetail" id="veg-6">
    <td valign="top" align="left"><img width="104" height="93" src="img/v4.jpg"></td>
    <td valign="middle" align="center"><strong>CAULIFLOWER High Grade(500 GM)</strong><br>
               <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">16</span></span> <br>
                                       SABJIONWHEELS PRICE: Rs <span class="s_pirce">13</span>
                                       <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
<tr class="proDetail" id="veg-72">
          <td valign="top" align="left"><img width="104" height="93" src="img/GanthG11.jpg"></td>
          <td valign="middle" align="center"><strong>GANTH GOBHI (500 GMS)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">40</span></span> <br>
            SABJIONWHEELS PRICE: Rs <span class="s_pirce">35</span>
            <div class="qtyDiv">
              <input type="button" value="+" class="button plus">
              <input type="button" value="-" class="button minus">
              <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]2">
            </div></td>
        </tr>

<tr class="proDetail" id="veg-7">
    <td valign="top" align="left"><img width="104" height="93" src="img/v7.jpg"></td>
    <td valign="middle" align="center"><strong>CAPSICUM - GREEN (250 GMS)</strong><br>
        <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">20</span></span> <br>
                                        SABJIONWHEELS PRICE: Rs <span class="s_pirce">16</span>
                                        <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>     </td>
  </tr>
 
  <tr class="proDetail" id="veg-23">
    <td valign="top" align="left"><img width="104" height="93" src="img/v24.jpg"></td>
    <td valign="middle" align="center"><strong>PETHA-GREEN (1KG)</strong><br>
          <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">50</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">45</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
 <tr class="proDetail" id="veg-87">
    <td valign="top" align="left"><img width="104" height="93" src="img/WP11.jpg"></td>
    <td valign="middle" align="center"><strong>PETHA- WHITE (500 GMS)</strong><br>
          <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">45</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">40</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
 
  <tr class="proDetail" id="veg-24">
    <td valign="top" align="left"><img width="104" height="93" src="img/v28.jpg"></td>
    <td valign="middle" align="center"><strong>RADDISH- WHITE (500 GMS)</strong><br>
      <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">13</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">10</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
<tr class="proDetail" id="veg-75">
    <td valign="top" align="left"><img width="104" height="93" src="img/RR11.jpg"></td>
    <td valign="middle" align="center"><strong>RADDISH RED - ORGANIC (250 GMS)</strong><br>
      <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">23</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">20</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>

<tr class="proDetail" id="veg-25">
        <td valign="top" align="left"><img width="104" height="93" src="img/v56.jpg"></td>
        <td valign="middle" align="center"><strong>SPINACH (paalak)(500 GMS)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs</strike><span class="market_pirce"> 20</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">18</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>          </td>
      </tr>

<tr class="proDetail" id="veg-82">
        <td valign="top" align="left"><img width="104" height="93" src="img/SS11.jpg"></td>
        <td valign="middle" align="center"><strong>SARSO KA SAAG(500 GMS)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs</strike><span class="market_pirce"> 18</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">15</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>          </td>
      </tr>
<tr class="proDetail" id="veg-3">
    <td width="28%" valign="top" align="left"><img width="104" height="93" src="img/v1.jpg"></td>
    <td width="72%" valign="middle" align="center"><strong>BROCCOLI (500 GMS)</strong><br>
         <span class="org-text"> <strike> MARKET PRICE: Rs </strike><span class="market_pirce">70
</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">45</span>
       <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>

  <tr class="proDetail" id="veg-8">
    <td valign="top" align="left"><img width="104" height="93" src="img/v5.jpg"></td>
    <td valign="middle" align="center"><strong>CAPSICUM-RED ORGANIC (1 Piece Approx 200 GMS)</strong><br>
         <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">51</span></span> <br>
         SABJIONWHEELS PRICE: Rs <span class="s_pirce">48</span>
         <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>     </td>
  </tr>
  <tr class="proDetail" id="veg-9">
    <td valign="top" align="left"><img width="104" height="93" src="img/v6.jpg"></td>
    <td valign="middle" align="center"><strong>CAPSICUM- YELLOW ORGANIC (1 Piece Approx 200 GMS)</strong><br>
        <span class="org-text"> <strike>MARKET PRICE: Rs </strike><span class="market_pirce">51</span></span> <br>
                              SABJIONWHEELS PRICE: Rs <span class="s_pirce">48</span>
                              <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
  
  <tr class="proDetail" id="veg-11">
    <td valign="top" align="left"><img width="104" height="93" src="img/v10.jpg"></td>
    <td valign="middle" align="center"><strong>CORINDER (DHANIYA) (100 GMS)</strong><br>
           <span class="org-text"><strike> MARKET PRICE: Rs 10</strike></span> <br>
           SABJIONWHEELS PRICE: Rs <span class="s_pirce">5</span>
           <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
  <tr class="proDetail" id="veg-12">
    <td valign="top" align="left"><img width="104" height="93" src="img/v11.jpg"></td>
    <td valign="middle" align="center"><strong>COCONUT &ndash; GREEN 1 Piece</strong><br>
                <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">45</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">40</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>     </td>
  </tr>
  <tr class="proDetail" id="veg-13">
    <td valign="top" align="left"><img width="104" height="93" src="img/v12.jpg"></td>
    <td valign="middle" align="center"><strong>COCONUT &ndash; BROWN 1 Piece</strong><br>
         <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">42</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">40</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
  <tr class="proDetail" id="veg-14">
    <td valign="top" align="left"><img width="104" height="93" src="img/v13.jpg"></td>
    <td valign="middle" align="center"><strong>GARLIC DESI (LAUSHAN) (100 GMS)</strong><br>
           <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">17</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">16</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
  <tr class="proDetail" id="veg-61">
    <td valign="top" align="left"><img width="104" height="93" src="img/v13.jpg"></td>
    <td valign="middle" align="center"><strong>GARLIC ORGANIC (LAUSHAN) (100 GMS)</strong><br>
           <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">25</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">22</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
  <tr class="proDetail" id="veg-15">
    <td valign="top" align="left"><img width="104" height="93" src="img/v14.jpg"></td>
    <td valign="middle" align="center"><strong>GINGER (ADRAK) (100 GMS</strong>)<br>
            <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">12</span></span> <br>
           SABJIONWHEELS PRICE: Rs <span class="s_pirce">10</span>
           <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>    </td>
  </tr>
  <tr class="proDetail" id="veg-16">
    <td valign="top" align="left"><img width="104" height="93" src="img/v15.jpg"></td>
    <td valign="middle" align="center"><strong>GREEN CHILLY (100 GMS)</strong><br>
         <span class="org-text"><strike> MARKET PRICE: Rs</strike> <span class="market_pirce">10</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">5</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
  <tr class="proDetail" id="veg-17">
    <td valign="top" align="left"><img width="104" height="93" src="img/v16.jpg"></td>
    <td valign="middle" align="center"><strong>LEMON - ORGANIC (100 GMS)</strong><br>
      <span class="org-text"><strike> MARKET PRICE: Rs</strike><span class="market_pirce"> 12</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">11</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>
  
  <tr class="proDetail" id="veg-53">
    <td valign="top" align="left"><img width="104" height="93" src="img/Greenlettuce112.jpg"></td>
    <td valign="middle" align="center"><strong>LETTUCE-GREEN (salad patta)(100 GMS)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs 26</strike></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">20</span>
       <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>     </td>
  </tr>
 
<tr class="proDetail" id="veg-79">
    <td valign="top" align="left"><img width="104" height="93" src="img/RP11.jpg"></td>
    <td valign="middle" align="center"><strong>Raw Papaya (500 GMS)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs 50</strike></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">40</span>
       <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>     </td>
  </tr>
 
<tr class="proDetail" id="veg-81">
    <td valign="top" align="left"><img width="104" height="93" src="img/kathal1234.jpg"></td>
    <td valign="middle" align="center"><strong>KATHAL (1 Packet 400 GMS)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs 42</strike></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">40</span>
       <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>     </td>
  </tr>

 
    </tbody></table>
    </td>
    <td width="50%" valign="top" align="left">
    <table width="100%" cellspacing="0" cellpadding="0" border="0" class="td-style2">
      <tbody>
<tr class="proDetail" id="veg-95">
        <td valign="top" align="left"><img width="104" height="93" src="img/SC-1.JPG"></td>
        <td valign="middle" align="center"><strong>Soya Chunks (200 GM)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">34</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">33</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
  </tr>
<tr class="proDetail" id="veg-96">
        <td valign="top" align="left"><img width="104" height="93" src="img/SG-1.JPG"></td>
        <td valign="middle" align="center"><strong>Soya Granules (200 GM)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">36</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">35</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
  </tr>


<tr class="proDetail" id="veg-28">
        <td valign="top" align="left"><img width="104" height="93" src="img/v20.jpg"></td>
        <td valign="middle" align="center"><strong>ONION HIGH GRADE (500 GM)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">21</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">18</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
  </tr>
<tr class="proDetail" id="veg-89">
        <td valign="top" align="left"><img width="104" height="93" src="img/WO11.jpg"></td>
        <td valign="middle" align="center"><strong>ONION - WHITE (500 GM)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">50</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">45</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
  </tr>

  <tr class="proDetail" id="veg-29">
    <td valign="top" align="left"><img width="104" height="93" src="img/v21.jpg"></td>
    <td valign="middle" align="center"><strong>ONION &ndash; SMALL(500 GMS)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">22</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">24</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>      </td>
  </tr>


<tr class="proDetail" id="veg-77">
          <td valign="top" align="left"><img width="104" height="93" src="img/SO11.jpg"></td>
          <td valign="middle" align="center"><strong>SPRING ONION - ORGANIC (250 GMS)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">15</span></span> <br>
            SABJIONWHEELS PRICE: Rs <span class="s_pirce">12</span>
            <div class="qtyDiv">
              <input type="button" value="+" class="button plus">
              <input type="button" value="-" class="button minus">
              <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]2">
            </div></td>
        </tr>
 

<tr class="proDetail" id="veg-70">
          <td valign="top" align="left"><img width="104" height="93" src="img/KC11.jpeg"></td>
          <td valign="middle" align="center"><strong>KACHALOO - COLOCASIA (500 GMS)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">35</span></span> <br>
            SABJIONWHEELS PRICE: Rs <span class="s_pirce">30</span>
            <div class="qtyDiv">
              <input type="button" value="+" class="button plus">
              <input type="button" value="-" class="button minus">
              <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]2">
            </div></td>
        </tr>
<tr class="proDetail" id="veg-76">
          <td valign="top" align="left"><img width="104" height="93" src="img/SP11.jpg"></td>
          <td valign="middle" align="center"><strong>SWEET POTATO - ORGANIC (500 GMS)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">30</span></span> <br>
            SABJIONWHEELS PRICE: Rs <span class="s_pirce">25</span>
            <div class="qtyDiv">
              <input type="button" value="+" class="button plus">
              <input type="button" value="-" class="button minus">
              <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]2">
            </div></td>
        </tr>


<tr class="proDetail" id="veg-69">
          <td valign="top" align="left"><img width="104" height="93" src="img/ME11.jpg"></td>
          <td valign="middle" align="center"><strong>Methi - ORGANIC (250 GMS)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">15</span></span> <br>
            SABJIONWHEELS PRICE: Rs <span class="s_pirce">13</span>
            <div class="qtyDiv">
              <input type="button" value="+" class="button plus">
              <input type="button" value="-" class="button minus">
              <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]2">
            </div></td>
        </tr>
<tr class="proDetail" id="veg-88">
          <td valign="top" align="left"><img width="104" height="93" src="img/BT11.jpg"></td>
          <td valign="middle" align="center"><strong>BATHUA (250 GMS)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">15</span></span> <br>
            SABJIONWHEELS PRICE: Rs <span class="s_pirce">10</span>
            <div class="qtyDiv">
              <input type="button" value="+" class="button plus">
              <input type="button" value="-" class="button minus">
              <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]2">
            </div></td>
        </tr>


<tr class="proDetail" id="veg-65">
          <td valign="top" align="left"><img width="104" height="93" src="img/Corn12344.jpg"></td>
          <td valign="middle" align="center"><strong>SWEET CORN ORGANIC(1 Packet)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">30</span></span> <br>
            SABJIONWHEELS PRICE: Rs <span class="s_pirce">22</span>
            <div class="qtyDiv">
              <input type="button" value="+" class="button plus">
              <input type="button" value="-" class="button minus">
              <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]2">
            </div></td>
        </tr>
 
 <tr class="proDetail" id="veg-27">
          <td valign="top" align="left"><img width="104" height="93" src="img/v30.jpg"></td>
          <td valign="middle" align="center"><strong>BABY CORN(1 Packet)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">40</span></span> <br>
            SABJIONWHEELS PRICE: Rs <span class="s_pirce">35</span>
            <div class="qtyDiv">
              <input type="button" value="+" class="button plus">
              <input type="button" value="-" class="button minus">
              <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]2">
            </div></td>
        </tr>
       <tr class="proDetail" id="veg-22">
          <td valign="top" align="left"><img width="104" height="93" src="img/sprouts1234.jpg"></td>
          <td valign="middle" align="center"><strong>SPROUTS (1 PACKET)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">26</span></span> <br>
            SABJIONWHEELS PRICE: Rs <span class="s_pirce">25</span>
            <div class="qtyDiv">
              <input type="button" value="+" class="button plus">
              <input type="button" value="-" class="button minus">
              <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]2">
            </div></td>
        </tr>
      
        <tr class="proDetail" id="veg-26">
          <td valign="top" align="left"><img width="104" height="93" src="img/sproutsmix1234.jpg"></td>
          <td valign="middle" align="center"><strong>SPROUTS MIX(1 Packet)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">26</span></span> <br>
            SABJIONWHEELS PRICE: Rs <span class="s_pirce">25</span>
            <div class="qtyDiv">
              <input type="button" value="+" class="button plus">
              <input type="button" value="-" class="button minus">
              <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]2">
            </div></td>
        </tr>
      
      
  
        

<tr class="proDetail" id="veg-31">
        <td width="28%" valign="top" align="left"><img width="104" height="93" src="img/v29.jpg"></td>
        <td width="72%" valign="middle" align="center"><strong>ARBI (250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">26</span></span> <br>
          SABJIONWHEELS PRICE: Rs<span class="s_pirce"> 23</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
      
      <tr class="proDetail" id="veg-33">
        <td valign="top" align="left"><img width="104" height="93" src="img/v32.jpg"></td>
        <td valign="middle" align="center"><strong>PEAS (MATAR)(250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">15</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">13</span>
           <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
      <tr class="proDetail" id="veg-34">
        <td valign="top" align="left"><img width="104" height="93" src="img/v33.jpg"></td>
        <td valign="middle" align="center"><strong>BEAT ROOT - Organic(250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs</strike> <span class="market_pirce">22</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">18</span>
           <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>

<tr class="proDetail" id="veg-86">
        <td valign="top" align="left"><img width="104" height="93" src="img/SG11.jpg"></td>
        <td valign="middle" align="center"><strong>SHALGUM (500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs</strike> <span class="market_pirce">25</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">20</span>
           <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
      

      <tr class="proDetail" id="veg-35">
        <td valign="top" align="left"><img width="104" height="93" src="img/v34.jpg"></td>
        <td valign="middle" align="center"><strong>BOTTLE GOURD (LOKKI)(500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">25</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">22</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
<tr class="proDetail" id="veg-68">
        <td valign="top" align="left"><img width="104" height="93" src="img/A12.jpg"></td>
        <td valign="middle" align="center"><strong>ROUND - BOTTLE GOURD(LOKKI)(500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">32</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">28</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>

      <tr class="proDetail" id="veg-36">
        <td valign="top" align="left" ><img width="104" height="93" src="img/v35.jpg"></td>
        <td valign="middle" align="center"><strong>BRINJAL &ndash; ROUND (500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">27</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">26</span>
           <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>     </td>
      </tr>
      <tr class="proDetail" id="veg-37">
        <td valign="top" align="left"><img width="104" height="93" src="img/v36.jpg"></td>
        <td valign="middle" align="center"><strong>BRINJAL- SMALL (250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">16</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">14</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
      <tr class="proDetail" id="veg-38">
        <td valign="top" align="left"><img width="104" height="93" src="img/v37.jpg"></td>
        <td valign="middle" align="center"><strong>BRINJAL-LONG (250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">15</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">13</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
      <tr class="proDetail" id="veg-39">
        <td valign="top" align="left"><img width="104" height="93" src="img/v38.jpg"></td>
        <td valign="middle" align="center"><strong>CUCUMBER - High Grade (KHIRA)(500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs 22</strike><span class="market_pirce"></span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">18</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>   </td>
      </tr>
<tr class="proDetail" id="veg-39">
        <td valign="top" align="left"><img width="104" height="93" src="img/chinesecucumber12.jpg"></td>
        <td valign="middle" align="center"><strong>CUCUMBER- Organic(500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs 35</strike><span class="market_pirce"></span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">34</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>   </td>
      </tr>
      
      <tr class="proDetail" id="veg-42">
        <td valign="top" align="left"><img width="104" height="93" src="img/JIMIKAND123.jpg"></td>
        <td valign="middle" align="center"><strong>JIMIKAND (TYPE OF ARBI)(1KG)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">100</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">80</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
      <tr class="proDetail" id="veg-43">
        <td valign="top" align="left"><img width="104" height="93" src="img/v40.jpg"></td>
        <td valign="middle" align="center"><strong>KADI PATTA (100 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">20</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">15</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
      <tr class="proDetail" id="veg-44">
        <td valign="top" align="left"><img width="104" height="93" src="img/RC11.jpeg"></td>
        <td valign="middle" align="center"><strong>RED CARROT (250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">12</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">9</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
      <tr class="proDetail" id="veg-45">
        <td valign="top" align="left"><img width="104" height="93" src="img/v42.jpg"></td>
        <td valign="middle" align="center"><strong>LOTUSSTEM (kamal kakdi)(250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">40</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">30</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
      <tr class="proDetail" id="veg-46">
        <td valign="top" align="left"><img width="104" height="93" src="img/v44.jpg"></td>
        <td valign="middle" align="center"><strong>MINT LEAVES (100 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">18</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">16</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
      <tr class="proDetail" id="veg-47">
        <td valign="top" align="left"><img width="104" height="93" src="img/v45.jpg"></td>
        <td valign="middle" align="center"><strong>MUSHROOM  (200 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">40</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">36</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div></td>
      </tr>
      
     
      <tr class="proDetail" id="veg-50">
        <td valign="top" align="left"><img width="104" height="93" src="img/v52.jpg"></td>
        <td valign="middle" align="center"><strong>ZUCCHINI (250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">42</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">35</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
      <tr class="proDetail" id="veg-51">
        <td valign="top" align="left"><img width="104" iheight="93" src="img/v53.jpg"></td>
        <td valign="middle" align="center"><strong>FRENCH BEANS (PHALI)(250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">20</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">18</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
<tr class="proDetail" id="veg-80">
        <td valign="top" align="left"><img width="104" iheight="93" src="img/MG11.jpg"></td>
        <td valign="middle" align="center"><strong>Moongre Beans (250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">18</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">15</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>

<tr class="proDetail" id="veg-84">
        <td valign="top" align="left"><img width="104" iheight="93" src="img/SB11.jpg"></td>
        <td valign="middle" align="center"><strong>SEM PHALI(250 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">15</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">14</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>

      
      <tr class="proDetail" id="veg-32">
        <td valign="top" align="left"><img width="104" height="93" src="img/tori1234.jpg"></td>
        <td valign="middle" align="center"><strong>Ridge Gourd(Tori)(500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">52</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">45</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
         </div>          </td>
      </tr>
    
        <tr class="proDetail" id="veg-26">
          <td valign="top" align="left"><img width="104" height="93" src="img/pumpkin-kaddu.jpg"></td>
          <td valign="middle" align="center"><strong>Pumpkin (Kaddu)(500 GM)</strong><br>
              <span class="org-text"><strike> MARKET PRICE: Rs </strike><span class="market_pirce">18</span></span> <br>
            SABJIONWHEELS PRICE: Rs <span class="s_pirce">20</span>
            <div class="qtyDiv">
              <input type="button" value="+" class="button plus">
              <input type="button" value="-" class="button minus">
              <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]2">
            </div></td>
        </tr>

          </tbody></table>
    </td>
  </tr>
</tbody></table>
</form>
<p></p>
 </div>
 </div>
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>