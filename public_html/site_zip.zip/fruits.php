<? 
include_once("config.php");
$site_title="Fruits";
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Free Home Delivery Fruits in Gurgaon</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="description" content="Feedback for Sabji On Wheels delivers fresh and best quality fruits at your doorstep in Gurgaon.">
<meta name="keywords" content="delivery fruit gurgaon, free delivery fruits in gurgaon, sabji market gurgaon">
<? include_once("commonTemplate/head.php")?> 


<!-- Facebook Conversion Code for Leads -->

<script>(function() {

var _fbq = window._fbq || (window._fbq = []);

if (!_fbq.loaded) {

var fbds = document.createElement('script');

fbds.async = true;

fbds.src = '//connect.facebook.net/en_US/fbds.js';

var s = document.getElementsByTagName('script')[0];

s.parentNode.insertBefore(fbds, s);

_fbq.loaded = true;

}

})();

window._fbq = window._fbq || [];

window._fbq.push(['track', '6015085393536', {'value':'0.00','currency':'INR'}]);

</script>

<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?ev=6015085393536&amp;cd[value]=0.00&amp;cd[currency]=INR&amp;noscript=1" /></noscript>




</head>

<body>
<? include_once("commonTemplate/header.php")?> 
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
    <div class="feeback-heading">Fruits</div>
    <div class="floating"><input type="button" value="Add to Cart" class="button add_to_cart_btn" id="button"  onClick="" />
   </div>

<table width="100%" cellspacing="0" cellpadding="0" border="1" class="td-style">
  <tbody><tr>
    <td width="50%" valign="top" align="left">
    <table width="100%" cellspacing="0" cellpadding="0" border="0" class="td-style2">
  <tbody>

<tr class="proDetail" id="fruit-54">
        <td valign="top" align="left"><img width="104" height="93" src="img/BR11.jpg"></td>
        <td valign="middle" align="center"><strong>Berr (1 KG)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">105</span></span> <br>
         SABJIONWHEELS PRICE: Rs <span class="s_pirce">98</span>
         <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
         </td>
      </tr>
<tr class="proDetail" id="fruit-55">
        <td valign="top" align="left"><img width="104" height="93" src="img/RS11.jpg"></td>
        <td valign="middle" align="center"><strong>RASBHARI (400GM)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">80</span></span> <br>
         SABJIONWHEELS PRICE: Rs <span class="s_pirce">60</span>
         <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
         </td>
      </tr>


<tr class="proDetail" id="fruit-17">
        <td valign="top" align="left"><img width="104" height="93" src="img/KI11.JPG"></td>
        <td valign="middle" align="center"><strong>KINNOW (500GM)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">22</span></span> <br>
         SABJIONWHEELS PRICE: Rs <span class="s_pirce">19</span>
         <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
         </td>
      </tr>


<tr class="proDetail" id="fruit-36">
        <td valign="top" align="left"><img width="104" height="93" src="img/SF11.jpg"></td>
        <td valign="middle" align="center"><strong>SHARON FRUIT- KAKI (Out Of Stock)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">0</span></span> <br>
         SABJIONWHEELS PRICE: Rs <span class="s_pirce">0</span>
         <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
         </td>
      </tr>


<tr class="proDetail" id="fruit-28">
        <td valign="top" align="left"><img width="104" height="93" src="img/PO11.jpg"></td>
        <td valign="middle" align="center"><strong>POMEGRANATE- High Grade (500GM)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">100</span></span> <br>
         SABJIONWHEELS PRICE: Rs <span class="s_pirce">90</span>
         <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
         </td>
      </tr>
      
<tr class="proDetail" id="fruit-50">
    <td valign="top" align="left"><img width="104" height="93" src="img/AW11.jpg"></td>
    <td valign="middle" align="center"><strong>APPLE-WASHINGTON(500 GM)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">120</span></span> <br>
  SABJIONWHEELS PRICE: Rs <span class="s_pirce">110</span>
  <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
  </td>
  </tr>
  

  <tr class="proDetail" id="fruit-8">
    <td valign="top" align="left"><img width="104" height="93" src="img/APPLE-FUJI.jpg"></td>
    <td valign="middle" align="center"><strong>APPLE-FUJI(500 GM)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">170</span></span> <br>
  SABJIONWHEELS PRICE: Rs <span class="s_pirce">149</span>
  <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
  </td>
  </tr>
  
   
<tr class="proDetail" id="fruit-51">
    <td width="28%" valign="top" align="left"><img width="104" height="93" src="img/AK11.jpg"></td>
    <td width="72%" valign="middle" align="center"><strong>APPLE-Kinnour HIGH GRADE(500 GM)<br>
      </strong>    <span class="org-text"> <strike> MARKET PRICE: Rs </strike> <span class="market_pirce">85</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">80</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
      </td>
  </tr>

<tr class="proDetail" id="fruit-49">
    <td width="28%" valign="top" align="left"><img width="104" height="93" src="img/GU11.jpg"></td>
    <td width="72%" valign="middle" align="center"><strong>GUAVA HIGH GRADE(500 GM)<br>
      </strong>    <span class="org-text"> <strike> MARKET PRICE: Rs </strike> <span class="market_pirce">42</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">35</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
      </td>
  </tr>



<tr class="proDetail" id="fruit-37">
    <td width="28%" valign="top" align="left"><img width="104" height="93" src="img/GUTA11.jpg"></td>
    <td width="72%" valign="middle" align="center"><strong>GUAVA THAILAND(1 KG)<br>
      </strong>    <span class="org-text"> <strike> MARKET PRICE: Rs </strike> <span class="market_pirce">400</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">349</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
      </td>
  </tr>


<tr class="proDetail" id="fruit-31">
    <td width="28%" valign="top" align="left"><img width="104" height="93" src="img/PL11.jpg"></td>
    <td width="72%" valign="middle" align="center"><strong>BLACK PLUMS - IMPORTED(500 GMS)<br>
      </strong>    <span class="org-text"> <strike> MARKET PRICE: Rs </strike> <span class="market_pirce">200</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">180</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
      </td>
  </tr>



  
  <tr class="proDetail" id="fruit-9">
    <td valign="top" align="left"><img width="100" height="80" src="img/BANANA - RAW.jpg"></td>
    <td valign="middle" align="center"><strong>BANANA &ndash; RAW (500 GMS)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">40</span></span> <br>
     SABJIONWHEELS PRICE: Rs <span class="s_pirce">35</span>
     <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
     </td>
  </tr>
    <tr class="proDetail" id="fruit-11">
    <td valign="top" align="left"><img width="104" height="93" src="img/BANAN-HIGHGR.jpg"></td>
    <td valign="middle" align="center"><strong>BANANA - HIGHGRADE 1 Piece<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">8</span></span> <br>
   SABJIONWHEELS PRICE: Rs <span class="s_pirce">7</span>
   <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
   </td>
  </tr>


  
  <tr class="proDetail" id="fruit-12">
    <td valign="top" align="left"><img width="104" height="93" src="img/PAPAYA123.jpg"></td>
    <td valign="middle" align="center"><strong>PAPAYA HIGH GRADE (Approx 1 - 1.25 KG)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">70</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">65</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
      </td>
  </tr>
  
  <tr class="proDetail" id="fruit-13">
    <td valign="top" align="left"><img width="104" height="93" src="img/PINEHIGHGRADE1234.jpg"></td>
    <td valign="middle" align="center"><strong>PINEAPPLE-ORGANIC (Approx 1.5 KG)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">120</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">110</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
      </td>
  </tr>
 

  <tr class="proDetail" id="fruit-15">
        <td valign="top" align="left"><img width="104" height="93" src="img/NC11.jpg"></td>
        <td valign="middle" align="center"><strong>NASHPATI - CHINA (500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">90</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">75</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
          </td>
   </tr>
   

<tr class="proDetail" id="fruit-46">
        <td valign="top" align="left"><img width="104" height="93" src="img/chiku.jpg"></td>
        <td valign="middle" align="center"><strong>Chikoo( 500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">40</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">34</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
          </td>
      </tr>




  </tbody></table>
</td>
    <td width="50%" valign="top" align="left">
    <table width="100%" cellspacing="0" cellpadding="0" border="0" class="td-style2">
      <tbody>


<tr class="proDetail" id="fruit-45">
    <td width="28%" valign="top" align="left"><img width="104" height="93" src="img/ST11.jpg"></td>
    <td width="72%" valign="middle" align="center"><strong>Strawberry(200 GM)<br>
      </strong>    <span class="org-text"> <strike> MARKET PRICE: Rs </strike> <span class="market_pirce">90</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">72</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
      </td>
  </tr>



<tr class="proDetail" id="fruit-35">
    <td width="28%" valign="top" align="left"><img width="104" height="93" src="img/AP11.jpg"></td>
    <td width="72%" valign="middle" align="center"><strong>APRICOT (1 Packet 200 GMS)<br>
      </strong>    <span class="org-text"> <strike> MARKET PRICE: Rs </strike> <span class="market_pirce">170</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">160</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
      </td>
  </tr>

 

 <tr class="proDetail" id="fruit-6">
    <td width="28%" valign="top" align="left"><img width="104" height="93" src="img/apple-green.jpg"></td>
    <td width="72%" valign="middle" align="center"><strong>APPLE-GREEN(500 GMS)<br>
      </strong>    <span class="org-text"> <strike> MARKET PRICE: Rs </strike> <span class="market_pirce">130</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">120</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
      </td>
  </tr>
<tr class="proDetail" id="fruit-56">
    <td valign="top" align="left"><img width="104" height="93" src="img/GG11.jpg"></td>
    <td valign="middle" align="center"><strong>Grapes Green - High Grade(500 GMS)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">80</span></span> <br>
  SABJIONWHEELS PRICE: Rs <span class="s_pirce">70</span>
  <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
  </td>
  </tr>

<tr class="proDetail" id="fruit-42">
    <td valign="top" align="left"><img width="104" height="93" src="img/BG11.jpg"></td>
    <td valign="middle" align="center"><strong>BLACK GRAPES - High Grade( 500 GMS)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">99</span></span> <br>
  SABJIONWHEELS PRICE: Rs <span class="s_pirce">70</span>
  <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
  </td>
  </tr>

  
<tr class="proDetail" id="fruit-10">
    <td valign="top" align="left"><img width="104" height="93" src="img/GRAPESCALIFORNIARED.jpg"></td>
    <td valign="middle" align="center"><strong>Grapes California(500 GM)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">250</span></span> <br>
  SABJIONWHEELS PRICE: Rs <span class="s_pirce">240</span>
  <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
  </td>
  </tr>



<tr class="proDetail" id="fruit-38">
    <td valign="top" align="left"><img width="104" height="93" src="img/IM11.jpg"></td>
    <td valign="middle" align="center"><strong>TAMARIND (IMLI)(1 Box)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">90</span></span> <br>
  SABJIONWHEELS PRICE: Rs <span class="s_pirce">80</span>
  <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
  </td>
  </tr>

<tr class="proDetail" id="fruit-39">
    <td valign="top" align="left"><img width="104" height="93" src="img/KH11.jpg"></td>
    <td valign="middle" align="center"><strong>DATES - KHAJUR(1 Packet 250 GMS)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">70</span></span> <br>
  SABJIONWHEELS PRICE: Rs <span class="s_pirce">65</span>
  <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
  </td>
  </tr>
<tr class="proDetail" id="fruit-48">
    <td valign="top" align="left"><img width="104" height="93" src="img/DC11.jpg"></td>
    <td valign="middle" align="center"><strong>DATES CROWN(1 Packet 500 GMS)<br>
      </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">125</span></span> <br>
  SABJIONWHEELS PRICE: Rs <span class="s_pirce">125</span>
  <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
  </td>
  </tr>
  

<tr class="proDetail" id="fruit-21">
        <td valign="top" align="left"><img width="104" height="93" src="img/watermelonhighgrade123.jpg"></td>
        <td valign="middle" align="center"><strong>WATERMELON 1 Piece (Approx 2-2.5 KG)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">70</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">65</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
          </td>
      </tr>

      
      
      <tr class="proDetail" id="fruit-23">
        <td valign="top" align="left"><img width="104" height="93" src="img/KIWI!!.jpg"></td>
        <td valign="middle" align="center"><strong>KIWI - NEW ZEALAND (1 Piece)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">42</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">39</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
          </td>
      </tr>
      <tr class="proDetail" id="fruit-24">
        <td valign="top" align="left"><img width="104" height="93" src="img/MOUSAMBI0123.jpg"></td>
        <td valign="middle" align="center"><strong>MAUSAMBI(500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">35</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">30</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
          </td>
      </tr>
<tr class="proDetail" id="fruit-47">
        <td valign="top" align="left"><img width="104" height="93" src="img/OR11.jpg"></td>
        <td valign="middle" align="center"><strong>ORANGE INDIAN HIGH GRADE(500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">55</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">50</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
          </td>
      </tr>

      <tr class="proDetail" id="fruit-25">
        <td valign="top" align="left"><img width="104" height="93" src="img/ORANGECALI123.jpg"></td>
        <td valign="middle" align="center"><strong>ORANGE &ndash; Malta(500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">90</span></span> <br>
          SABJIONWHEELS PRICE: Rs <span class="s_pirce">85</span>
          <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
          </td>
      </tr>
     
      
  <tr class="proDetail" id="fruit-52">
        <td valign="top" align="left"><img width="104" height="93" src="img/BUSA11.jpg"></td>
        <td valign="middle" align="center"><strong>Babugosha - USA(500 GMS)<br>
          </strong> <span class="org-text"><strike> MARKET PRICE: Rs </strike> <span class="market_pirce">130</span></span> <br>
      SABJIONWHEELS PRICE: Rs <span class="s_pirce">120</span>
      <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
      </td>
      </tr>
  


        


      </tbody></table></td>
  </tr>
</tbody></table>
<p></p> </div>
 </div>
</section>
<? include_once("commonTemplate/footer.php")?> 
</body>
</html>
