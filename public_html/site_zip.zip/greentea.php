<? 
include_once("config.php");
$site_title="Flour";
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Organic India Green Teas &amp; Herbal tea Gurgaon</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="description" content="Fruit basket with fresh and best quality fruits &amp; vegetables at your doorstep directly with the best farmers in Gurgaon.">
<meta name="keywords" content="Weekly box, home delivery vegetables, free delivery fruits in gurgaon, sabji market gurgaon, organic india green tea, Green tea, green tea home delivery, herbal tea ">

<? include_once("commonTemplate/head.php")?>
</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
  <div class="feeback-heading">ORGANIC INDIA GREEN TEA</div>
  <div class="floating"><input type="button" value="Add to Cart" class="button add_to_cart_btn" id="button"  onClick="" />
   </div>
<div id="container">
	<div class="original-box2 proDetail" id="Green-1"><h2><strong>Organic India Tulsi Green Tea 25 TB (Out Of Stock)/-</strong></h2>
    <img width="170" height="200" src="img/OITG-25-tea-bags-box.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 0.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
25 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Stress Relieving  <br>
2. Energizing <br>
3. Protect Immune System <br>
		</div>
	</div>
	<div class="original-box2 proDetail" id="Green-2"><h2><strong>Organic India Tulsi Lemon Ginger Green Tea (Out Of Stock)</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-lemon-ginger-green-tea-25.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 0 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
25 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Stress Relieving  <br>
2. Energizing <br>
3. Exhilarating <br>
4. Powerful Adaptogen <br>
		</div>
	</div>

<div class="original-box2 proDetail" id="Green-3"><h2><strong>Organic India Tulsi Honey Chamomile Tea - MRP. 128</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-honey-chamomile-tea.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 103.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
18 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Stress Relieving  <br>
2. Restorative <br>
3. Caffine & Gluten Free <br>
4. Powerful Adaptogen <br>
		</div>
	</div>
<hr>
<div class="original-box2 proDetail" id="Green-4"><h2><strong>Organic India Tulsi Earl Grey Green Tea - MRP. 154</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-earl-grey-green-tea-18-tea-bags-box.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 123.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
18 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Stress Relieving  <br>
2. Aromatic <br>
		</div>
	</div>

<div class="original-box2 proDetail" id="Green-5"><h2><strong>Organic India Tulsi Original Green Tea - MRP. 118</strong></h2>
    <img width="180" height="200" src="img/OI-original-tulsi-25-tea-bags-box.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 96.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
25 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Reduces Stress  <br>
2. Promotes Calmness & Clarity <br>
3. Minimizes Cold & Flu Symptoms <br>

		</div>
	</div>


<div class="original-box2 proDetail" id="Green-6"><h2><strong>Organic India Tulsi Pomegranate Green Tea - MRP. 154</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-pomegranate-green-tea.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 123.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
25 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Reduces Stress  <br>
2. Invigorating <br>
3. Powerful Adaptogen <br>
4. Gluten Free <br>
3. GMO free <br>
3. Kosher <br>

		</div>
	</div>

<hr>
<div class="original-box2 proDetail" id="Green-7"><h2><strong>Organic India Tulsi Brahami Tea - MRP. 154</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-brahmi-tea-25-tea-bags-box.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 123.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
25 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Stress Relieving  <br>
2. Memory Booster <br>
3. Increase Intelligence Level <br>
4. Treats Insomania caused due to Stress <br>
5. Reduces head Trauma <br>
6. Improves Poor brain function <br>
		</div>
	</div>

<div class="original-box2 proDetail" id="Green-8"><h2><strong>Organic India Tulsi Mulethi Tea - MRP. 118</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-mulethi-18-tea-bags-box.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 96.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
18 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Reduces Stress  <br>
2. Vitalizing <br>
3. Caffine Free <br>

		</div>
	</div>


<div class="original-box2 proDetail" id="Green-9"><h2><strong>Organic India Tulsi Tummy Tea - MRP. 125</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-tummy-18-tea-bags.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 100.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
18 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Soothing Digestive Support  <br>

		</div>
	</div>
<hr>
<div class="original-box2 proDetail" id="Green-10"><h2><strong>Organic India Tulsi Jasmine Green Tea - Out Of Stock</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-jasmine-green-tea-18-tea-bags-box.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 0.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
18 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Stress Relieving  <br>
2. Slimming <br>
		</div>
	</div>

<div class="original-box2 proDetail" id="Green-11"><h2><strong>Organic India Tulsi Cleanse Green Tea - MRP. 125</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-cleanse-18-tea-bags.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 100.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
18 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Daily Liver & Kidney Support  <br>
2. Promotes Calmness & Clarity <br>


		</div>
	</div>


<div class="original-box2 proDetail" id="Green-12"><h2><strong>Organic India Tulsi Ginger Green Tea - MRP. 118</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-ginger-25-tea-bags-box.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 96.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
25 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Reduces Stress  <br>
2. Uplifting <br>
3. Builds Immunity <br>
4. Improves Stamina <br>

		</div>
	</div>
<hr>
<div class="original-box2 proDetail" id="Green-13"><h2><strong>Organic India Tulsi Green Tea (Out Of Stock)</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-green-tea-100-gram-loose-tea-tin.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 0.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
100 GMS GMS Loose Tea Tin

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Stress Relieving  <br>
2. Slimming <br>
3. Enhances Stamina <br>
4. Builds Immunity <br>

		</div>
	</div>

<div class="original-box2 proDetail" id="Green-14"><h2><strong>Organic India Tulsi Ginger Tea - MRP. 170</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-ginger-100-gram-loose-tea-tin.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 136.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
100 GMS GMS Loose Tea Tin

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Stress Relieving  <br>
2. Uplifting <br>
3. Rich in Antioxidants <br>
4. Guards against Cough & Cold <br>

		</div>
	</div>


<div class="original-box2 proDetail" id="Green-15"><h2><strong>Organic India Tulsi Original Tea - MRP. 180</strong></h2>
    <img width="180" height="200" src="img/OI-original-tulsi-100-gram-loose-tea-tin.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 144.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
100 GMS GMS Loose Tea Tin

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Build Stamina  <br>
2. Uplifting <br>
3. Rich in Antioxidants <br>
4. Protects Immune System <br>

		</div>
	</div>

<hr>

<div class="original-box2 proDetail" id="Green-16"><h2><strong>Organic India Tulsi Chai Masala Tea (Out Of Stock)</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-chai-masala-tea-100-gram-loose-tea-tin.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 0 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
100 GMS GMS Loose Tea Tin

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Reduces Stress  <br>
2. Uplifting <br>
3. Enhances Stamina <br>
4. Guard Against Cough & Cold <br>

		</div>
	</div>

<div class="original-box2 proDetail" id="Green-17"><h2><strong>Organic India Tulsi Sweet Rose Tea - MRP. 118</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-sweet-rose-18-tea-bags-box.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 96.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
18 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Stress Releiving <br>
2. Delightful <br>
3. Caffine Free <br>

		</div>
	</div>


<div class="original-box2 proDetail" id="Green-18"><h2><strong>Organic India Tulsi Chai Masala Tea - MRP. 154</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-chai-masala-tea-25-tea-bags-box.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 123.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
25 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Reduces Stress  <br>
2. Uplifting <br>
3. Rejuvenating <br>

		</div>
	</div>
<hr>
<div class="original-box2 proDetail" id="Green-19"><h2><strong>Organic India Tulsi Sleep Tea - MRP. 145</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-sleep-18-tea-bags.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 116.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
18 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Promotes Calm & Restful Sleep  <br>
2. Stress Releiving <br>
		</div>
	</div>

<div class="original-box2 proDetail" id="Green-20"><h2><strong>Organic India Tulsi Wellness Lax Tea - (Out Of Stock)</strong></h2>
    <img width="180" height="200" src="img/OI-wellness-tulsi-lax-18-tea-bags.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 0 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
18 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Gentle, Effective Herbal Laxative  <br>
2. Promotes Calmness & Clarity <br>


		</div>
	</div>


<div class="original-box2 proDetail" id="Green-21"><h2><strong>Organic India Tulsi Sweet Lemon Tea - MRP. 124</strong></h2>
    <img width="180" height="200" src="img/OI-tulsi-sweet-lemon-tea-18-tea-bags-box.jpg"><br>

OFFER PRICE:Rs<span class="s_pirce"> 99.00 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
18 Tea Bags Box

		<div class="popup-box2 popup-box2-left">
			<strong>Benefits:</strong><br>
1. Reduces Stress  <br>
2. Uplifting <br>
3. Refreshing <br>

		</div>
	</div>


</div><!-- #container --> </div>
 </div>
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>
