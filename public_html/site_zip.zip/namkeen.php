<? 
include_once("config.php");
$site_title="Combo Offers";
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Home Made Nakeens &amp; Nakeens Gurgaon</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="description" content="Homemade namkeens with fresh and best quality ingredients &amp; homemade namkeens at your doorstep directly with the best chefs in Gurgaon.">
<meta name="keywords" content="Homemade namkeens, home delivery homemade namkeens, free delivery namkeens in gurgaon, sabji market gurgaon, party snakcs basket, snacks basket ">

<? include_once("commonTemplate/head.php")?>
</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
  <div class="feeback-heading">Homemade Delicious Namkeens by Chef. Sushma Tomar</div>
  <div class="floating"><input type="button" value="Add to Cart" class="button add_to_cart_btn" id="button"  onClick="" />
   </div>
<div id="container">
	<div class="original-box2 proDetail" id="Namkeen-1"><h2><strong>Mathris (250 GMS)</strong></h2>
    <img width="190" height="190" src="img/methris.JPG"><br>

Sabji On Wheels Price:Rs<span class="s_pirce"> 70 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>

Homemade Delicious Mathris<br>
By Chef. Sushma Tomar
		<div class="popup-box2 popup-box2-left">
			<strong>Ingredients:</strong><br>

Maida<br>
Sooji<br>
Salt<br>
Ajwayin<br>
Nature's Fresh Oil<br>
		</div>
	</div>

<div id="container">
	<div class="original-box2 proDetail" id="Namkeen-2"><h2><strong>Chiwda Namkeen (250 GMS)</strong></h2>
    <img width="190" height="190" src="img/chiwda.JPG"><br>

Sabji On Wheels Price:Rs<span class="s_pirce"> 70 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>

Homemade Delicious Chiwda<br>
By Chef. Sushma Tomar
		<div class="popup-box2 popup-box2-left">
			<strong>Ingredients:</strong><br>

Chiwda<br> 
Khurme<br> 
Groundnuts<br> 
Cashewnuts<br> 
Nature's Fresh Oil<br> 
Salt<br> 
Chaat Masala
		</div>
	</div>
<div id="container">
	<div class="original-box2 proDetail" id="Namkeen-3"><h2><strong>Khurme Namkeen (250 GMS)</strong></h2>
    <img width="190" height="190" src="img/khurme.jpg"><br>

Sabji On Wheels Price:Rs<span class="s_pirce"> 58 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>

Homemade Delicious Namekeen Khurme<br>
By Chef. Sushma Tomar
		<div class="popup-box2 popup-box2-left">
			<strong>Ingredients:</strong><br>

Maida<br>
Sooji<br>
Salt<br>
Ajwayin<br>
Nature's Fresh Oil<br>
		</div>
	</div>
<hr>
<div id="container">
	<div class="original-box2 proDetail" id="Namkeen-4"><h2><strong>Moong Daal Samosa (250 GMS)</strong></h2>
    <img width="190" height="190" src="img/samose.JPG"><br>

Sabji On Wheels Price:Rs<span class="s_pirce"> 70 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>

Homemade Delicious Moong Dal Samose<br>
By Chef. Sushma Tomar
		<div class="popup-box2 popup-box2-left">
			<strong>Ingredients:</strong><br>

Maida<br> 
Moong Dal<br> 
Spices<br> 
Salt<br> 
Nature's Fresh Oil<br>
		</div>
	</div>


<hr>

<br>
<br>

</div><!-- #container --> </div>
<div class="feeback-heading">Note: For Bulk Orders, Place your orders 2 days before.</div>
 </div>
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>
