<style>
.custom-font-1.trans-1 > span {
    margin-bottom: 10px;
    margin-left: 10px;
}

#fancybox-content span {
    width:39%;
}

</style>
<div class="light-box">
<span>
 <a class="button-3 custom-font-1 trans-1" href="cart.php"><span>Proceed to checkout</span></a>
</span>
<span>
 <a class="button-3 custom-font-1 trans-1" href="greentea.php"><span>Add Green Tea</span></a>
</span>

<span>
 <a class="button-3 custom-font-1 trans-1" href="Spices.php"><span>Add Spices</span></a>
</span>
<span>
 <a class="button-3 custom-font-1 trans-1" href="vegetables.php"><span>Add more Veggies</span></a>
</span>
<span>
 <a class="button-3 custom-font-1 trans-1" href="fruits.php"><span>Add more Fruits</span></a>
</span>
<span>
 <a class="button-3 custom-font-1 trans-1" href="weekly.php?ref=cart"><span>Add Weekly Boxes</span></a>
</span>
<span>
 <a class="button-3 custom-font-1 trans-1" href="health.php?ref=cart"><span>Add Health Boxes</span></a>
</span>
<span>
 <a class="button-3 custom-font-1 trans-1" href="combooffers.php?ref=cart"><span>Add Combo Offers</span></a>
</span>

</div>
																				
