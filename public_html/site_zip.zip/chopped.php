<? include_once("config.php");
$site_title="Offer";
?>
<!DOCTYPE HTML>
<html>
<head>
<? include_once("commonTemplate/head.php")?>
</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
<div class="divbox-left">
<div class="feeback-heading" style="color:#C0504D">COMING SOON

<iframe src='http://www.flipkart.com/affiliate/displayWidget?affrid=WRID-140732180212636799' height=55 width=660 scrolling='no' frameborder=0></iframe>

</div>

</div></div></div>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>
