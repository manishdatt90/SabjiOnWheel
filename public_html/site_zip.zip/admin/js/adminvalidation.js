function Delete()
{	
	return confirm("Are you sure want to delete record!");
}