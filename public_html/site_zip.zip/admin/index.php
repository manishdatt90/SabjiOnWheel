<?
include_once($_SERVER['DOCUMENT_ROOT']."/config.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>sabjionwheels</title>
<frameset border="0" rows="96,*" framespacing="0" frameborder="no">
	<frame src="templates/header.html"  frameborder="no" marginheight="0" marginwidth="0" scrolling="no"/>
	<frameset border="0" cols="230,*" rows="*" framespacing="0" frameborder="no">
		<frame marginheight="0" marginwidth="0" name="left_nav" src="leftnav.php"/>
		<frameset border="0" rows="*,20" framespacing="0" frameborder="no">
			<frame marginheight="0" marginwidth="0" name="main" src="main.php" frameborder="no" marginheight="0" marginwidth="0"/>
			<frame src="templates/footer.html" frameborder="no" marginheight="0" marginwidth="0" scrolling="no" style="text-align:center"/>
<frame src="UntitledFrame-1"></frameset>
</frameset>
</frameset>
	<noframes></noframes>
</head>
<body>
</body>
</html>
