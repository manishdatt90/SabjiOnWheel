<? 
include_once("config.php");
$site_title="Combo Offers";
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Gift Combo Offers &amp; Vegetables Gurgaon</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<meta name="description" content="Fruit basket with fresh and best quality fruits &amp; vegetables at your doorstep directly with the best farmers in Gurgaon.">
<meta name="keywords" content="Weekly box, home delivery vegetables, free delivery fruits in gurgaon, sabji market gurgaon, marriage fruit basket, fruit basket ">

<? include_once("commonTemplate/head.php")?>
</head>

<body>
<? include_once("commonTemplate/header.php")?>
<section>
<div class="feedback-outer">
  <div class="feedback-inner">
  <div class="feeback-heading">Combo Offers of the Week</div>
  <div class="floating"><input type="button" value="Add to Cart" class="button add_to_cart_btn" id="button"  onClick="" />
   </div>
<div id="container">
	<div class="original-box2 proDetail" id="Basket-1"><h2><strong>Chilly & Haldi Powder (100 GMS) @ Rs 1/-. For bills Rs. 400+</strong></h2>
    <img width="170" height="140" src="img/400++.jpg"><br>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">45</span></span> <br>

Sabji On Wheels Price:Rs<span class="s_pirce"> 1 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>

Only One offer valid on every order.<br>
Advance Order Discount not applicable on this offer.
		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>

Chilly Powder & Haldi Powder (100 GMS Each) @ Rs. 1<br>

Eligible for orders above Rs 400. <br><br>

Only One offer would be valid on every order. <br><br>
No Other Advance order discounts would be applicable after applying this offer.<br>
		</div>
	</div>

	<div class="original-box2 proDetail" id="Basket-2"><h2><strong>Garam Masala Powder @ Rs. 1<br> For all bills Rs. 600 & Above</strong></h2>
    <img width="170" height="140" src="img/600++.jpg"><br>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">70</span></span> <br>

Sabji On Wheels Price:Rs<span class="s_pirce"> 1 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
Only One offer valid on every order.<br>
Advance Order Discount not applicable on this offer.
		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>

Garam Masala Powder (100 GMS) @ Rs. 1<br>

Eligible for orders above Rs 600. <br><br>

Only One offer would be valid on every order. <br><br>
No Other Advance order discounts would be applicable after applying this offer.<br>
</div>
	</div>
	<div class="original-box2 proDetail" id="Basket-3"><h2><strong>Sabji & Kitchen King Masala (100 GMS) @ Rs. 1/- For bill Rs. 800+ </strong></h2>
    <img width="170" height="140" src="img/800+.jpg"><br>
<span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">95</span></span> <br>

Sabji On Wheels Price:Rs<span class="s_pirce"> 1 </span><br><div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
Only One offer valid on every order.<br>
Advance Order Discount not applicable on this offer.

		<div class="popup-box2 popup-box2-left">
			<strong>Products:</strong><br>


Sabji Masala & Kitchen King Masala Powder (100 GMS) @ Rs. 1<br>

Eligible for orders above Rs 800. <br><br>

Only One offer would be valid on every order. <br><br>
No Other Advance order discounts would be applicable after applying this offer.<br>
		</div>
	</div>
<hr>
	<div class="original-box2 proDetail" id="Basket-6"><h2><strong>1 KG Peas Shimla <br>(Limited to 1 QTY Per Order) </strong></h2>
    <img width="220" height="180" img src="img/peas1kg@49.jpg"><br>
 <span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">60</span></span> <br>

Sabji On Wheels Price:Rs <span class="s_pirce">49.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div> 
		</div>


<div class="original-box2 proDetail" id="Basket-4"><h2><strong> Brocolli (Approx 400- 500 GMS) <br>(Limited to 1 QTY Per Order)</strong></h2>
    <img width="220" height="180" img src="img/brocoli@29.jpg"><br>
 <span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">69</span></span> <br>

Sabji On Wheels Price:Rs <span class="s_pirce">29.00</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		</div>
<div class="original-box2 proDetail" id="Basket-7"><h2><strong>Sweetcorn 200 GMS <br>(Limited to 1 Qty Per Order)</strong></h2>
    <img width="220" height="180" img src="img/sweetcron@16.jpg"><br>
 <span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">30</span></span> <br>

Sabji On Wheels Price:Rs <span class="s_pirce">16</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		</div>
<hr>
<div class="original-box2 proDetail" id="Basket-6"><h2><strong>Cauliflower 1 KG <br> (Limited to 1 QTY Per Order)</strong></h2>
    <img width="220" height="180" img src="img/cauliflower@19.jpg"><br>
 <span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">40</span></span> <br>

Sabji On Wheels Price:Rs <span class="s_pirce">19</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		</div>
<div class="original-box2 proDetail" id="Basket-8"><h2><strong>2 Packet Mushroom<br> (Limited to 1 Qty Per Order)</strong></h2>
    <img width="220" height="180" img src="img/mushroom@49.jpg"><br>
 <span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">80</span></span> <br>

Sabji On Wheels Price:Rs <span class="s_pirce">49</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		</div>
<div class="original-box2 proDetail" id="Basket-8"><h2><strong>1 Box Strawberry (200 GMS)</strong></h2>
    <img width="220" height="180" img src="img/Strawberry12.jpg"><br>
 <span class="org-text"><strike> MRP: Rs </strike><span class="market_pirce">80</span></span> <br>

Sabji On Wheels Price:Rs <span class="s_pirce">65</span><br>
 <div class="qtyDiv">	
            <input type="button" value="+" class="button plus">
            <input type="button" value="-" class="button minus">
            <input type="text"  value="0" size="2" class="proQty"  name="prod_qty[]">
     </div>
		</div>



<hr>

<br>
<br>
<div class="feeback-heading">Note: Products in Offers are 100% Fresh & Hygenic.</div>

</div><!-- #container --> </div>
 
 </div>
</section>
<? include_once("commonTemplate/footer.php")?>
</body>
</html>
